"use client"

import React, { createContext, useContext, useState, ReactNode } from 'react'

// Types
export interface Product {
  id: number
  name: string
  price: number
  originalPrice?: number
  image: string
  description: string
  rating: number
  reviews: number
  category: string
  badge?: string
  inStock: boolean
}

export interface CartItem extends Product {
  quantity: number
}

export interface User {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  twoFactorEnabled: boolean
}

export interface Message {
  id: string
  sender: 'user' | 'support' | 'seller'
  content: string
  timestamp: Date
}

export interface Track {
  id: string
  title: string
  artist: string
  cover: string
  audioUrl: string
  videoUrl?: string
}

interface StoreContextType {
  // Auth
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  register: (data: { name: string; email: string; phone: string; password: string }) => Promise<boolean>
  setUser: React.Dispatch<React.SetStateAction<User | null>>
  
  // Cart
  cart: CartItem[]
  addToCart: (product: Product) => void
  removeFromCart: (productId: number) => void
  updateQuantity: (productId: number, quantity: number) => void
  clearCart: () => void
  cartTotal: number
  cartCount: number
  
  // UI State
  currentView: 'login' | 'register' | 'forgot-password' | 'verify-2fa' | 'main'
  setCurrentView: (view: 'login' | 'register' | 'forgot-password' | 'verify-2fa' | 'main') => void
  isSidebarOpen: boolean
  setIsSidebarOpen: (open: boolean) => void
  isCartOpen: boolean
  setIsCartOpen: (open: boolean) => void
  isChatOpen: boolean
  setIsChatOpen: (open: boolean) => void
  isSupportChatOpen: boolean
  setIsSupportChatOpen: (open: boolean) => void
  isLiveOpen: boolean
  setIsLiveOpen: (open: boolean) => void
  isAIToolOpen: boolean
  setIsAIToolOpen: (open: boolean) => void
  
  // Music Player
  currentTrack: Track | null
  setCurrentTrack: (track: Track | null) => void
  isPlaying: boolean
  setIsPlaying: (playing: boolean) => void
  isLocked: boolean
  setIsLocked: (locked: boolean) => void
  showVideo: boolean
  setShowVideo: (show: boolean) => void
  playlist: Track[]
  nextTrack: () => void
  
  // Messages
  sellerMessages: Message[]
  supportMessages: Message[]
  addSellerMessage: (content: string, sender: 'user' | 'seller') => void
  addSupportMessage: (content: string, sender: 'user' | 'support') => void
  
  // Search
  searchQuery: string
  setSearchQuery: (query: string) => void
  
  // Products
  products: Product[]
}

const StoreContext = createContext<StoreContextType | undefined>(undefined)

// Sample products data
const sampleProducts: Product[] = [
  {
    id: 1,
    name: "Sabonete Lavanda Relaxante",
    price: 18.90,
    originalPrice: 24.90,
    image: "https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=400&h=400&fit=crop",
    description: "Sabonete artesanal com óleo essencial de lavanda para relaxamento",
    rating: 4.8,
    reviews: 234,
    category: "Relaxante",
    badge: "Mais Vendido",
    inStock: true
  },
  {
    id: 2,
    name: "Sabonete Esfoliante Aveia",
    price: 15.90,
    image: "https://images.unsplash.com/photo-1617897903246-719242758050?w=400&h=400&fit=crop",
    description: "Esfoliação suave com aveia orgânica para pele macia",
    rating: 4.6,
    reviews: 189,
    category: "Esfoliante",
    inStock: true
  },
  {
    id: 3,
    name: "Sabonete Rosa Mosqueta",
    price: 22.90,
    originalPrice: 29.90,
    image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop",
    description: "Hidratação profunda com óleo de rosa mosqueta",
    rating: 4.9,
    reviews: 312,
    category: "Hidratante",
    badge: "Premium",
    inStock: true
  },
  {
    id: 4,
    name: "Sabonete Carvão Ativado",
    price: 19.90,
    image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=400&h=400&fit=crop",
    description: "Limpeza profunda com carvão ativado detox",
    rating: 4.7,
    reviews: 156,
    category: "Detox",
    inStock: true
  },
  {
    id: 5,
    name: "Sabonete Mel e Própolis",
    price: 16.90,
    image: "https://images.unsplash.com/photo-1612817288484-6f916006741a?w=400&h=400&fit=crop",
    description: "Antibacteriano natural com mel e própolis",
    rating: 4.5,
    reviews: 98,
    category: "Antibacteriano",
    inStock: true
  },
  {
    id: 6,
    name: "Sabonete Aloe Vera",
    price: 14.90,
    image: "https://images.unsplash.com/photo-1599305090598-fe179d501227?w=400&h=400&fit=crop",
    description: "Hidratação e calmante para peles sensíveis",
    rating: 4.8,
    reviews: 267,
    category: "Hidratante",
    badge: "Novo",
    inStock: true
  },
  {
    id: 7,
    name: "Sabonete Argila Verde",
    price: 17.90,
    image: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=400&h=400&fit=crop",
    description: "Controle de oleosidade com argila verde",
    rating: 4.4,
    reviews: 145,
    category: "Oleosidade",
    inStock: true
  },
  {
    id: 8,
    name: "Sabonete Camomila Calmante",
    price: 15.90,
    image: "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=400&h=400&fit=crop",
    description: "Suavidade e calma com extrato de camomila",
    rating: 4.6,
    reviews: 178,
    category: "Calmante",
    inStock: true
  },
  {
    id: 9,
    name: "Sabonete Café Energizante",
    price: 20.90,
    originalPrice: 25.90,
    image: "https://images.unsplash.com/photo-1556227703-a86c04a3f0a7?w=400&h=400&fit=crop",
    description: "Estimulante com grãos de café esfoliantes",
    rating: 4.7,
    reviews: 203,
    category: "Energizante",
    badge: "Promoção",
    inStock: true
  },
  {
    id: 10,
    name: "Sabonete Eucalipto Refrescante",
    price: 16.90,
    image: "https://images.unsplash.com/photo-1584305574647-0cc949a2bb9f?w=400&h=400&fit=crop",
    description: "Frescor e limpeza com óleo de eucalipto",
    rating: 4.5,
    reviews: 134,
    category: "Refrescante",
    inStock: true
  },
  {
    id: 11,
    name: "Sabonete Manga Tropical",
    price: 18.90,
    image: "https://images.unsplash.com/photo-1601055283742-8b27e81b5553?w=400&h=400&fit=crop",
    description: "Fragrância tropical com manteiga de manga",
    rating: 4.8,
    reviews: 189,
    category: "Hidratante",
    inStock: true
  },
  {
    id: 12,
    name: "Sabonete Calêndula Cicatrizante",
    price: 21.90,
    image: "https://images.unsplash.com/photo-1556228852-6d35a585d566?w=400&h=400&fit=crop",
    description: "Propriedades cicatrizantes da calêndula",
    rating: 4.9,
    reviews: 256,
    category: "Medicinal",
    badge: "Top 10",
    inStock: true
  },
  {
    id: 13,
    name: "Sabonete Limão Siciliano",
    price: 14.90,
    image: "https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=400&h=400&fit=crop",
    description: "Frescor cítrico para o dia a dia",
    rating: 4.4,
    reviews: 112,
    category: "Refrescante",
    inStock: true
  },
  {
    id: 14,
    name: "Sabonete Jasmim Noturno",
    price: 23.90,
    originalPrice: 28.90,
    image: "https://images.unsplash.com/photo-1617897903246-719242758050?w=400&h=400&fit=crop",
    description: "Fragrância sofisticada de jasmim",
    rating: 4.8,
    reviews: 198,
    category: "Premium",
    badge: "Luxo",
    inStock: true
  },
  {
    id: 15,
    name: "Sabonete Bamboo Detox",
    price: 19.90,
    image: "https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop",
    description: "Limpeza profunda com extrato de bamboo",
    rating: 4.6,
    reviews: 167,
    category: "Detox",
    inStock: true
  },
  {
    id: 16,
    name: "Sabonete Coco Nutritivo",
    price: 15.90,
    image: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?w=400&h=400&fit=crop",
    description: "Nutrição intensa com óleo de coco virgem",
    rating: 4.7,
    reviews: 223,
    category: "Nutritivo",
    inStock: true
  },
  {
    id: 17,
    name: "Sabonete Romã Antioxidante",
    price: 22.90,
    image: "https://images.unsplash.com/photo-1612817288484-6f916006741a?w=400&h=400&fit=crop",
    description: "Poder antioxidante da romã",
    rating: 4.8,
    reviews: 187,
    category: "Antioxidante",
    badge: "Novo",
    inStock: true
  },
  {
    id: 18,
    name: "Sabonete Gengibre Aquecedor",
    price: 17.90,
    image: "https://images.unsplash.com/photo-1599305090598-fe179d501227?w=400&h=400&fit=crop",
    description: "Sensação aquecedora com gengibre",
    rating: 4.5,
    reviews: 134,
    category: "Estimulante",
    inStock: true
  },
  {
    id: 19,
    name: "Sabonete Maracujá Relaxante",
    price: 16.90,
    image: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?w=400&h=400&fit=crop",
    description: "Relaxamento com óleo de maracujá",
    rating: 4.6,
    reviews: 156,
    category: "Relaxante",
    inStock: true
  },
  {
    id: 20,
    name: "Sabonete Karité Premium",
    price: 26.90,
    originalPrice: 32.90,
    image: "https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=400&h=400&fit=crop",
    description: "Hidratação premium com manteiga de karité",
    rating: 4.9,
    reviews: 298,
    category: "Premium",
    badge: "Best Seller",
    inStock: true
  }
]

// Sample playlist
const samplePlaylist: Track[] = [
  {
    id: '1',
    title: 'Relaxing Nature',
    artist: 'Ambient Sounds',
    cover: 'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=200&h=200&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    videoUrl: 'https://www.youtube.com/embed/lTRiuFIWV54'
  },
  {
    id: '2',
    title: 'Ocean Waves',
    artist: 'Nature Sounds',
    cover: 'https://images.unsplash.com/photo-1505142468610-359e7d316be0?w=200&h=200&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    videoUrl: 'https://www.youtube.com/embed/WHPEKLQID4U'
  },
  {
    id: '3',
    title: 'Peaceful Piano',
    artist: 'Calm Music',
    cover: 'https://images.unsplash.com/photo-1507838153414-b4b713384a76?w=200&h=200&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    videoUrl: 'https://www.youtube.com/embed/77ZozI0rw7w'
  },
  {
    id: '4',
    title: 'Morning Meditation',
    artist: 'Zen Master',
    cover: 'https://images.unsplash.com/photo-1528715471579-d1bcf0ba5e83?w=200&h=200&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    videoUrl: 'https://www.youtube.com/embed/inpok4MKVLM'
  },
  {
    id: '5',
    title: 'Forest Rain',
    artist: 'Natural Harmony',
    cover: 'https://images.unsplash.com/photo-1534274988757-a28bf1a57c17?w=200&h=200&fit=crop',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    videoUrl: 'https://www.youtube.com/embed/q76bMs-NwRk'
  }
]

export function StoreProvider({ children }: { children: ReactNode }) {
  // Auth state
  const [user, setUser] = useState<User | null>(null)
  const [currentView, setCurrentView] = useState<'login' | 'register' | 'forgot-password' | 'verify-2fa' | 'main'>('login')
  
  // Cart state
  const [cart, setCart] = useState<CartItem[]>([])
  
  // UI state
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isSupportChatOpen, setIsSupportChatOpen] = useState(false)
  const [isLiveOpen, setIsLiveOpen] = useState(false)
  const [isAIToolOpen, setIsAIToolOpen] = useState(false)
  
  // Music player state
  const [currentTrack, setCurrentTrack] = useState<Track | null>(samplePlaylist[0])
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLocked, setIsLocked] = useState(false)
  const [showVideo, setShowVideo] = useState(false)
  
  // Messages state
  const [sellerMessages, setSellerMessages] = useState<Message[]>([
    { id: '1', sender: 'seller', content: 'Olá! Como posso ajudar você hoje?', timestamp: new Date() }
  ])
  const [supportMessages, setSupportMessages] = useState<Message[]>([
    { id: '1', sender: 'support', content: 'Bem-vindo ao suporte! Como podemos ajudar?', timestamp: new Date() }
  ])
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('')
  
  // Auth functions
  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulated login
    if (email && password.length >= 6) {
      const mockUser: User = {
        id: '1',
        name: 'Usuário Teste',
        email: email,
        phone: '(11) 99999-9999',
        twoFactorEnabled: true
      }
      setUser(mockUser)
      return true
    }
    return false
  }
  
  const logout = () => {
    setUser(null)
    setCurrentView('login')
    setCart([])
  }
  
  const register = async (data: { name: string; email: string; phone: string; password: string }): Promise<boolean> => {
    // Simulated registration
    if (data.name && data.email && data.phone && data.password.length >= 6) {
      const newUser: User = {
        id: Date.now().toString(),
        name: data.name,
        email: data.email,
        phone: data.phone,
        twoFactorEnabled: false
      }
      setUser(newUser)
      return true
    }
    return false
  }
  
  // Cart functions
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id)
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { ...product, quantity: 1 }]
    })
  }
  
  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId))
  }
  
  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
      return
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    )
  }
  
  const clearCart = () => setCart([])
  
  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0)
  
  // Music functions
  const nextTrack = () => {
    const currentIndex = samplePlaylist.findIndex(t => t.id === currentTrack?.id)
    const nextIndex = (currentIndex + 1) % samplePlaylist.length
    setCurrentTrack(samplePlaylist[nextIndex])
  }
  
  // Message functions
  const addSellerMessage = (content: string, sender: 'user' | 'seller') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      sender,
      content,
      timestamp: new Date()
    }
    setSellerMessages(prev => [...prev, newMessage])
    
    // Auto-reply simulation
    if (sender === 'user') {
      setTimeout(() => {
        const replies = [
          'Entendi! Vou verificar isso para você.',
          'Temos esse produto em estoque, sim!',
          'Posso oferecer um desconto especial para você.',
          'Qual sua preferência de fragrância?',
          'Esse é um dos nossos mais vendidos!'
        ]
        const randomReply = replies[Math.floor(Math.random() * replies.length)]
        setSellerMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: 'seller',
          content: randomReply,
          timestamp: new Date()
        }])
      }, 1500)
    }
  }
  
  const addSupportMessage = (content: string, sender: 'user' | 'support') => {
    const newMessage: Message = {
      id: Date.now().toString(),
      sender,
      content,
      timestamp: new Date()
    }
    setSupportMessages(prev => [...prev, newMessage])
    
    // Auto-reply simulation
    if (sender === 'user') {
      setTimeout(() => {
        const replies = [
          'Entendemos sua preocupação. Vamos resolver isso!',
          'Obrigado por entrar em contato. Um momento...',
          'Podemos ajudar com isso! Qual seu número de pedido?',
          'Nossa equipe está analisando sua solicitação.',
          'Agradecemos o feedback! Vamos melhorar.'
        ]
        const randomReply = replies[Math.floor(Math.random() * replies.length)]
        setSupportMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: 'support',
          content: randomReply,
          timestamp: new Date()
        }])
      }, 1500)
    }
  }
  
  const isAuthenticated = !!user
  
  return (
    <StoreContext.Provider value={{
      user,
      isAuthenticated,
      login,
      logout,
      register,
      setUser,
      cart,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartTotal,
      cartCount,
      currentView,
      setCurrentView,
      isSidebarOpen,
      setIsSidebarOpen,
      isCartOpen,
      setIsCartOpen,
      isChatOpen,
      setIsChatOpen,
      isSupportChatOpen,
      setIsSupportChatOpen,
      isLiveOpen,
      setIsLiveOpen,
      isAIToolOpen,
      setIsAIToolOpen,
      currentTrack,
      setCurrentTrack,
      isPlaying,
      setIsPlaying,
      isLocked,
      setIsLocked,
      showVideo,
      setShowVideo,
      playlist: samplePlaylist,
      nextTrack,
      sellerMessages,
      supportMessages,
      addSellerMessage,
      addSupportMessage,
      searchQuery,
      setSearchQuery,
      products: sampleProducts
    }}>
      {children}
    </StoreContext.Provider>
  )
}

export function useStore() {
  const context = useContext(StoreContext)
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider')
  }
  return context
}

"use client"

import { useStore } from '@/lib/store-context'
import { Search, ShoppingCart, Menu, X } from 'lucide-react'
import { useState } from 'react'

export function Header() {
  const { 
    cartCount, 
    setIsCartOpen, 
    isSidebarOpen, 
    setIsSidebarOpen,
    searchQuery,
    setSearchQuery
  } = useStore()
  const [isSearchFocused, setIsSearchFocused] = useState(false)

  return (
    <header className="sticky top-0 z-40 w-full">
      <div className="glass border-b border-glass-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Menu Button */}
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-xl glass-button hover:scale-105 transition-all duration-300"
              aria-label={isSidebarOpen ? 'Fechar menu' : 'Abrir menu'}
            >
              {isSidebarOpen ? (
                <X className="w-6 h-6 text-foreground" />
              ) : (
                <Menu className="w-6 h-6 text-foreground" />
              )}
            </button>

            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg">
                <span className="text-lg font-bold text-primary-foreground">SB</span>
              </div>
              <span className="hidden sm:block text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                SoapBubble
              </span>
            </div>

            {/* Search Bar */}
            <div className={`flex-1 max-w-xl mx-4 transition-all duration-300 ${isSearchFocused ? 'scale-105' : ''}`}>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Buscar sabonetes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setIsSearchFocused(false)}
                  className="w-full h-11 pl-10 pr-4 rounded-xl glass-button border-glass-border 
                           focus:border-primary focus:ring-2 focus:ring-primary/20 
                           transition-all duration-300 bg-card/50 text-foreground placeholder:text-muted-foreground"
                />
                <button
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg 
                           bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-medium
                           hover:opacity-90 transition-all duration-300"
                >
                  Buscar
                </button>
              </div>
            </div>

            {/* Cart Button */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 rounded-xl glass-button hover:scale-105 transition-all duration-300"
              aria-label="Abrir carrinho"
            >
              <ShoppingCart className="w-6 h-6 text-foreground" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-secondary to-primary 
                               text-primary-foreground text-xs font-bold flex items-center justify-center
                               animate-in zoom-in duration-300">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

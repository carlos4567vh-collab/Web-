"use client"

import { useStore } from '@/lib/store-context'
import { 
  Phone, ShoppingBag, Shirt, TrendingUp, Globe, Award, 
  Grid3X3, FileText, Store, Smartphone, X, Music, ChevronRight,
  MessageCircle, Headphones, Video, Sparkles, LogOut, User
} from 'lucide-react'
import { MusicPlayer } from '@/components/features/music-player'

const menuItems = [
  { icon: Phone, label: 'Contato', href: '#contato' },
  { icon: ShoppingBag, label: 'Supermercado', href: '#supermercado' },
  { icon: Shirt, label: 'Moda', href: '#moda' },
  { icon: TrendingUp, label: 'Mais Vendidos', href: '#mais-vendidos' },
  { icon: Globe, label: 'Compra Internacional', href: '#internacional', badge: 'NOVO' },
  { icon: Award, label: 'Lojas Oficiais', href: '#lojas-oficiais', badge: 'NOVO' },
  { icon: Grid3X3, label: 'Categorias', href: '#categorias' },
  { icon: FileText, label: 'Resumo', href: '#resumo' },
  { icon: Store, label: 'Vender', href: '#vender' },
  { icon: Smartphone, label: 'Compre e venda com o app', href: '#app' },
]

const resourceItems = [
  { icon: MessageCircle, label: 'Chat com Vendedor', action: 'chat' },
  { icon: Headphones, label: 'Suporte', action: 'support' },
  { icon: Video, label: 'Lives', action: 'live' },
  { icon: Sparkles, label: 'Ferramenta IA', action: 'ai' },
]

export function Sidebar() {
  const { 
    isSidebarOpen, 
    setIsSidebarOpen,
    setIsChatOpen,
    setIsSupportChatOpen,
    setIsLiveOpen,
    setIsAIToolOpen,
    user,
    logout
  } = useStore()

  const handleResourceClick = (action: string) => {
    switch (action) {
      case 'chat':
        setIsChatOpen(true)
        break
      case 'support':
        setIsSupportChatOpen(true)
        break
      case 'live':
        setIsLiveOpen(true)
        break
      case 'ai':
        setIsAIToolOpen(true)
        break
    }
    setIsSidebarOpen(false)
  }

  return (
    <>
      {/* Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`fixed top-0 left-0 h-full w-80 z-50 transform transition-transform duration-300 ease-out
                   ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="h-full glass-card rounded-none rounded-r-3xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-glass-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-lg font-bold text-primary-foreground">SB</span>
              </div>
              <div>
                <h2 className="font-semibold text-foreground">Menu</h2>
                <p className="text-xs text-muted-foreground">Navegue pelo site</p>
              </div>
            </div>
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="p-2 rounded-xl glass-button hover:scale-105 transition-all"
            >
              <X className="w-5 h-5 text-foreground" />
            </button>
          </div>

          {/* User Info */}
          {user && (
            <div className="p-4 border-b border-glass-border">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <User className="w-6 h-6 text-primary-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-foreground truncate">{user.name}</p>
                  <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                </div>
              </div>
            </div>
          )}

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto">
            {/* Menu Items */}
            <nav className="p-4">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Navegação
              </h3>
              <ul className="space-y-1">
                {menuItems.map((item, index) => (
                  <li key={index}>
                    <a
                      href={item.href}
                      onClick={() => setIsSidebarOpen(false)}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-muted/50 
                               transition-all duration-200 group"
                    >
                      <item.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                      <span className="flex-1 text-foreground group-hover:text-primary transition-colors">
                        {item.label}
                      </span>
                      {item.badge && (
                        <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-secondary to-primary 
                                       text-primary-foreground text-xs font-semibold">
                          {item.badge}
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 
                                             transform translate-x-0 group-hover:translate-x-1 transition-all" />
                    </a>
                  </li>
                ))}
              </ul>
            </nav>

            {/* Resources */}
            <div className="p-4 border-t border-glass-border">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Recursos
              </h3>
              <ul className="space-y-1">
                {resourceItems.map((item, index) => (
                  <li key={index}>
                    <button
                      onClick={() => handleResourceClick(item.action)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-muted/50 
                               transition-all duration-200 group"
                    >
                      <item.icon className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                      <span className="flex-1 text-left text-foreground group-hover:text-primary transition-colors">
                        {item.label}
                      </span>
                      <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 
                                             transform translate-x-0 group-hover:translate-x-1 transition-all" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Music Player Section */}
            <div className="p-4 border-t border-glass-border">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <Music className="w-4 h-4" />
                Player de Música
              </h3>
              <MusicPlayer />
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-glass-border">
            <button
              onClick={logout}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl 
                       bg-destructive/10 hover:bg-destructive/20 text-destructive 
                       transition-all duration-200"
            >
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Sair</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}

"use client"

import { 
  Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin, 
  Shield, CreditCard, Truck, Clock
} from 'lucide-react'

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Youtube, href: '#', label: 'YouTube' },
]

const footerLinks = {
  institucional: [
    { label: 'Sobre Nós', href: '#' },
    { label: 'Nossa História', href: '#' },
    { label: 'Trabalhe Conosco', href: '#' },
    { label: 'Blog', href: '#' },
  ],
  ajuda: [
    { label: 'Central de Ajuda', href: '#' },
    { label: 'Como Comprar', href: '#' },
    { label: 'Formas de Pagamento', href: '#' },
    { label: 'Prazo de Entrega', href: '#' },
  ],
  legal: [
    { label: 'Termos de Uso', href: '#' },
    { label: 'Política de Privacidade', href: '#' },
    { label: 'Trocas e Devoluções', href: '#' },
    { label: 'Segurança', href: '#' },
  ]
}

const features = [
  { icon: Shield, label: 'Compra Segura', description: '100% protegido' },
  { icon: CreditCard, label: 'Parcele em 12x', description: 'Sem juros' },
  { icon: Truck, label: 'Frete Grátis', description: 'Acima de R$99' },
  { icon: Clock, label: 'Suporte 24h', description: 'Sempre disponível' },
]

export function Footer() {
  return (
    <footer className="mt-auto">
      {/* Features Bar */}
      <div className="glass border-t border-glass-border">
        <div className="container mx-auto px-4 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 
                              flex items-center justify-center">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{feature.label}</p>
                  <p className="text-xs text-muted-foreground">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="glass border-t border-glass-border">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Brand */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary 
                              flex items-center justify-center shadow-lg">
                  <span className="text-xl font-bold text-primary-foreground">SB</span>
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary 
                               bg-clip-text text-transparent">
                  SoapBubble
                </span>
              </div>
              <p className="text-muted-foreground max-w-sm">
                O maior marketplace de sabonetes artesanais do Brasil. Produtos naturais, 
                feitos com amor e ingredientes de qualidade.
              </p>
              
              {/* Contact Info */}
              <div className="space-y-2">
                <a href="mailto:contato@soapbubble.com" 
                   className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                  <Mail className="w-4 h-4" />
                  contato@soapbubble.com
                </a>
                <a href="tel:+5511999999999" 
                   className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                  <Phone className="w-4 h-4" />
                  (11) 99999-9999
                </a>
                <p className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  São Paulo, SP - Brasil
                </p>
              </div>

              {/* Social Links */}
              <div className="flex gap-3">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 rounded-xl glass-button flex items-center justify-center
                             hover:scale-110 hover:bg-primary hover:text-primary-foreground 
                             transition-all duration-300"
                  >
                    <social.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Institucional */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Institucional</h4>
              <ul className="space-y-2">
                {footerLinks.institucional.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} 
                       className="text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Ajuda */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Ajuda</h4>
              <ul className="space-y-2">
                {footerLinks.ajuda.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} 
                       className="text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground">Legal</h4>
              <ul className="space-y-2">
                {footerLinks.legal.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} 
                       className="text-muted-foreground hover:text-primary transition-colors">
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="glass border-t border-glass-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>&copy; 2024 SoapBubble. Todos os direitos reservados.</p>
            <div className="flex items-center gap-4">
              <span>Pagamentos seguros:</span>
              <div className="flex gap-2">
                {['Visa', 'Master', 'Pix', 'Boleto'].map((method) => (
                  <span key={method} className="px-2 py-1 rounded glass-button text-xs">
                    {method}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

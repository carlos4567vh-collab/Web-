"use client"

import { useEffect, useState } from 'react'

export function AnimatedBackground() {
  const [gradientIndex, setGradientIndex] = useState(0)

  const gradients = [
    'from-violet-500/30 via-fuchsia-500/20 to-cyan-500/30',
    'from-rose-500/30 via-amber-500/20 to-violet-500/30',
    'from-cyan-500/30 via-emerald-500/20 to-rose-500/30',
    'from-amber-500/30 via-rose-500/20 to-indigo-500/30',
    'from-indigo-500/30 via-cyan-500/20 to-emerald-500/30',
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setGradientIndex((prev) => (prev + 1) % gradients.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [gradients.length])

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Animated gradient background */}
      <div 
        className={`absolute inset-0 bg-gradient-to-br ${gradients[gradientIndex]} transition-all duration-[3000ms] ease-in-out animate-gradient`}
        style={{ backgroundSize: '400% 400%' }}
      />
      
      {/* Floating orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-gradient-to-br from-accent/20 to-primary/20 blur-3xl animate-float" style={{ animationDelay: '-2s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-secondary/10 to-accent/10 blur-3xl animate-pulse-slow" />
      
      {/* Mesh gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-background/0 via-background/50 to-background" />
      
      {/* Subtle noise texture */}
      <div className="absolute inset-0 opacity-[0.015]" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }} />
    </div>
  )
}

"use client"

import { useState, useRef, useEffect } from 'react'
import { useStore } from '@/lib/store-context'
import { Button } from '@/components/ui/button'
import { Loader2, Shield, ArrowLeft } from 'lucide-react'

export function Verify2FAForm() {
  const { setCurrentView, user, setUser } = useStore()
  const [code, setCode] = useState(['', '', '', '', '', ''])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [resendCooldown, setResendCooldown] = useState(0)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    // Focus first input on mount
    inputRefs.current[0]?.focus()
  }, [])

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [resendCooldown])

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) {
      // Handle paste
      const digits = value.replace(/\D/g, '').slice(0, 6).split('')
      const newCode = [...code]
      digits.forEach((digit, i) => {
        if (index + i < 6) {
          newCode[index + i] = digit
        }
      })
      setCode(newCode)
      const nextIndex = Math.min(index + digits.length, 5)
      inputRefs.current[nextIndex]?.focus()
      return
    }

    if (!/^\d*$/.test(value)) return

    const newCode = [...code]
    newCode[index] = value
    setCode(newCode)
    setError('')

    // Move to next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus()
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    const fullCode = code.join('')
    if (fullCode.length !== 6) {
      setError('Por favor, digite o código completo')
      return
    }

    setIsLoading(true)
    
    // Simulated verification
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsLoading(false)

    // Accept any 6-digit code for demo
    if (user) {
      setUser({ ...user, twoFactorEnabled: true })
    }
    setCurrentView('main')
  }

  const handleResend = () => {
    setResendCooldown(60)
    setCode(['', '', '', '', '', ''])
    inputRefs.current[0]?.focus()
  }

  const handleSkip = () => {
    setCurrentView('main')
  }

  return (
    <div className="w-full max-w-md mx-auto p-8">
      <div className="glass-card p-8 space-y-6">
        {/* Back button */}
        <button
          type="button"
          onClick={() => setCurrentView('login')}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </button>

        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <Shield className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Verificação em 2 Etapas</h1>
          <p className="text-muted-foreground">
            Digite o código de 6 dígitos enviado para seu email ou telefone
          </p>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm text-center">
            {error}
          </div>
        )}

        {/* Code inputs */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center gap-3">
            {code.map((digit, index) => (
              <input
                key={index}
                ref={(el) => { inputRefs.current[index] = el }}
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-14 text-center text-xl font-bold rounded-xl glass-button border-glass-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
              />
            ))}
          </div>

          <Button
            type="submit"
            disabled={isLoading || code.some(d => !d)}
            className="w-full h-12 bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all duration-300 text-primary-foreground font-semibold rounded-xl shadow-lg"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              'Verificar'
            )}
          </Button>
        </form>

        {/* Resend and Skip */}
        <div className="space-y-3">
          <p className="text-center text-sm text-muted-foreground">
            Não recebeu o código?{' '}
            {resendCooldown > 0 ? (
              <span className="text-primary">Reenviar em {resendCooldown}s</span>
            ) : (
              <button
                type="button"
                onClick={handleResend}
                className="text-primary hover:text-primary/80 font-semibold transition-colors"
              >
                Reenviar
              </button>
            )}
          </p>
          
          <button
            type="button"
            onClick={handleSkip}
            className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Pular verificação (demonstração)
          </button>
        </div>
      </div>
    </div>
  )
}

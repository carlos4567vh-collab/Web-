"use client"

import { useState } from 'react'
import { useStore } from '@/lib/store-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Mail, Phone, Loader2, ArrowLeft, CheckCircle } from 'lucide-react'

export function ForgotPasswordForm() {
  const { setCurrentView } = useStore()
  const [method, setMethod] = useState<'email' | 'phone'>('email')
  const [value, setValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSent, setIsSent] = useState(false)
  const [error, setError] = useState('')

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '')
    if (numbers.length <= 11) {
      return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3')
    }
    return value
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    if (!value) {
      setError(`Por favor, digite seu ${method === 'email' ? 'email' : 'telefone'}`)
      return
    }

    setIsLoading(true)
    
    // Simulated API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setIsLoading(false)
    setIsSent(true)
  }

  if (isSent) {
    return (
      <div className="w-full max-w-md mx-auto p-8">
        <div className="glass-card p-8 space-y-6 text-center">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Código Enviado!</h1>
          <p className="text-muted-foreground">
            {method === 'email' 
              ? `Enviamos um link de recuperação para ${value}`
              : `Enviamos um código SMS para ${value}`
            }
          </p>
          <Button
            onClick={() => setCurrentView('login')}
            className="w-full h-12 bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all duration-300 text-primary-foreground font-semibold rounded-xl shadow-lg"
          >
            Voltar ao Login
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md mx-auto p-8">
      <div className="glass-card p-8 space-y-6">
        {/* Back button */}
        <button
          type="button"
          onClick={() => setCurrentView('login')}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </button>

        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <span className="text-2xl font-bold text-primary-foreground">SB</span>
          </div>
          <h1 className="text-2xl font-bold text-foreground">Recuperar Senha</h1>
          <p className="text-muted-foreground">Escolha como deseja recuperar sua senha</p>
        </div>

        {/* Method selection */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => { setMethod('email'); setValue(''); setError(''); }}
            className={`flex-1 py-3 px-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 ${
              method === 'email' 
                ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg' 
                : 'glass-button'
            }`}
          >
            <Mail className="w-5 h-5" />
            Email
          </button>
          <button
            type="button"
            onClick={() => { setMethod('phone'); setValue(''); setError(''); }}
            className={`flex-1 py-3 px-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 ${
              method === 'phone' 
                ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg' 
                : 'glass-button'
            }`}
          >
            <Phone className="w-5 h-5" />
            Telefone
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm text-center">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              {method === 'email' ? 'Email' : 'Telefone'}
            </label>
            <div className="relative">
              {method === 'email' ? (
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              ) : (
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              )}
              <Input
                type={method === 'email' ? 'email' : 'tel'}
                placeholder={method === 'email' ? 'seu@email.com' : '(00) 00000-0000'}
                value={value}
                onChange={(e) => setValue(method === 'phone' ? formatPhone(e.target.value) : e.target.value)}
                className="pl-10 h-12 glass-button border-glass-border"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all duration-300 text-primary-foreground font-semibold rounded-xl shadow-lg"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              `Enviar código por ${method === 'email' ? 'Email' : 'SMS'}`
            )}
          </Button>
        </form>
      </div>
    </div>
  )
}

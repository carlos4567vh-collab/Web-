"use client"

import { useState, useEffect } from 'react'
import { ChevronLeft, ChevronRight, Sparkles, Gift, Truck } from 'lucide-react'
import { Button } from '@/components/ui/button'

const banners = [
  {
    id: 1,
    title: 'Sabonetes Artesanais',
    subtitle: 'Feitos com amor e ingredientes naturais',
    description: 'Descubra nossa coleção exclusiva de sabonetes artesanais',
    cta: 'Ver Coleção',
    gradient: 'from-violet-600 via-purple-600 to-fuchsia-600',
    image: 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=800&h=600&fit=crop'
  },
  {
    id: 2,
    title: 'Frete Grátis',
    subtitle: 'Nas compras acima de R$ 99',
    description: 'Aproveite e monte seu kit de cuidados pessoais',
    cta: 'Comprar Agora',
    gradient: 'from-emerald-600 via-teal-600 to-cyan-600',
    image: 'https://images.unsplash.com/photo-1617897903246-719242758050?w=800&h=600&fit=crop'
  },
  {
    id: 3,
    title: 'Kit Presente',
    subtitle: 'Perfeito para quem você ama',
    description: 'Kits especiais com embalagem premium',
    cta: 'Presentear',
    gradient: 'from-rose-600 via-pink-600 to-fuchsia-600',
    image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=800&h=600&fit=crop'
  }
]

const features = [
  { icon: Sparkles, label: '100% Natural', description: 'Ingredientes orgânicos' },
  { icon: Gift, label: 'Embalagem Premium', description: 'Perfeito para presente' },
  { icon: Truck, label: 'Entrega Rápida', description: 'Em até 3 dias úteis' },
]

export function PromoBanners() {
  const [currentBanner, setCurrentBanner] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 6000)
    return () => clearInterval(timer)
  }, [])

  const goToPrev = () => {
    setCurrentBanner((prev) => (prev - 1 + banners.length) % banners.length)
  }

  const goToNext = () => {
    setCurrentBanner((prev) => (prev + 1) % banners.length)
  }

  return (
    <section className="py-6">
      <div className="container mx-auto px-4 space-y-6">
        {/* Main Banner Carousel */}
        <div className="relative overflow-hidden rounded-3xl">
          <div 
            className="flex transition-transform duration-700 ease-out"
            style={{ transform: `translateX(-${currentBanner * 100}%)` }}
          >
            {banners.map((banner) => (
              <div 
                key={banner.id} 
                className="w-full flex-shrink-0 relative"
              >
                <div className={`relative h-[300px] md:h-[400px] bg-gradient-to-r ${banner.gradient} overflow-hidden`}>
                  {/* Background Image */}
                  <div className="absolute inset-0">
                    <img 
                      src={banner.image} 
                      alt={banner.title}
                      className="w-full h-full object-cover opacity-30"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 via-foreground/30 to-transparent" />
                  </div>
                  
                  {/* Content */}
                  <div className="relative h-full flex items-center">
                    <div className="container mx-auto px-8 md:px-12">
                      <div className="max-w-lg space-y-4">
                        <span className="inline-block px-4 py-1 rounded-full bg-background/20 backdrop-blur-sm 
                                       text-background text-sm font-medium">
                          {banner.subtitle}
                        </span>
                        <h2 className="text-4xl md:text-5xl font-bold text-background leading-tight">
                          {banner.title}
                        </h2>
                        <p className="text-background/80 text-lg">
                          {banner.description}
                        </p>
                        <Button 
                          size="lg"
                          className="bg-background text-foreground hover:bg-background/90 
                                   rounded-xl font-semibold shadow-xl"
                        >
                          {banner.cta}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={goToPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full 
                     glass flex items-center justify-center hover:scale-110 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-foreground" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full 
                     glass flex items-center justify-center hover:scale-110 transition-transform"
          >
            <ChevronRight className="w-6 h-6 text-foreground" />
          </button>

          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentBanner(index)}
                className={`h-2 rounded-full transition-all duration-300 
                           ${index === currentBanner 
                             ? 'w-8 bg-background' 
                             : 'w-2 bg-background/50 hover:bg-background/70'}`}
              />
            ))}
          </div>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="glass-card p-6 flex items-center gap-4 hover:shadow-xl transition-shadow"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 
                            flex items-center justify-center">
                <feature.icon className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{feature.label}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

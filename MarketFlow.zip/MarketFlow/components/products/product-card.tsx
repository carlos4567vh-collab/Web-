"use client"

import { useState } from 'react'
import { useStore, Product } from '@/lib/store-context'
import { ShoppingCart, Heart, Star, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useStore()
  const [isLiked, setIsLiked] = useState(false)
  const [isAdded, setIsAdded] = useState(false)

  const handleAddToCart = () => {
    addToCart(product)
    setIsAdded(true)
    setTimeout(() => setIsAdded(false), 2000)
  }

  const discount = product.originalPrice 
    ? Math.round((1 - product.price / product.originalPrice) * 100) 
    : 0

  return (
    <div className="group glass-card overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.badge && (
            <span className="px-3 py-1 rounded-full bg-gradient-to-r from-primary to-secondary 
                           text-primary-foreground text-xs font-semibold shadow-lg">
              {product.badge}
            </span>
          )}
          {discount > 0 && (
            <span className="px-3 py-1 rounded-full bg-gradient-to-r from-green-500 to-emerald-600 
                           text-white text-xs font-semibold shadow-lg">
              -{discount}%
            </span>
          )}
        </div>

        {/* Like Button */}
        <button
          onClick={() => setIsLiked(!isLiked)}
          className={`absolute top-3 right-3 w-10 h-10 rounded-full glass-button 
                     flex items-center justify-center transition-all duration-300
                     ${isLiked ? 'bg-red-500/20 text-red-500' : 'text-muted-foreground hover:text-red-500'}`}
        >
          <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
        </button>

        {/* Quick Add Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-transparent to-transparent 
                       opacity-0 group-hover:opacity-100 transition-opacity duration-300 
                       flex items-end justify-center pb-4">
          <Button
            onClick={handleAddToCart}
            disabled={isAdded}
            className={`px-6 py-2 rounded-xl font-semibold transition-all duration-300 transform 
                       translate-y-4 group-hover:translate-y-0
                       ${isAdded 
                         ? 'bg-green-500 text-white' 
                         : 'bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90'}`}
          >
            {isAdded ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                Adicionado!
              </>
            ) : (
              <>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Adicionar
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Category */}
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {product.category}
        </span>

        {/* Name */}
        <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors">
          {product.name}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`w-4 h-4 ${i < Math.floor(product.rating) 
                  ? 'text-amber-400 fill-amber-400' 
                  : 'text-muted-foreground/30'}`} 
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">
            ({product.reviews})
          </span>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold text-foreground">
            R$ {product.price.toFixed(2).replace('.', ',')}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              R$ {product.originalPrice.toFixed(2).replace('.', ',')}
            </span>
          )}
        </div>

        {/* Stock Status */}
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${product.inStock ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className={`text-sm ${product.inStock ? 'text-green-600' : 'text-red-500'}`}>
            {product.inStock ? 'Em estoque' : 'Indisponível'}
          </span>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleAddToCart}
            disabled={isAdded || !product.inStock}
            className={`flex-1 h-11 rounded-xl font-semibold transition-all duration-300
                       ${isAdded 
                         ? 'bg-green-500 text-white' 
                         : 'bg-gradient-to-r from-primary to-secondary text-primary-foreground hover:opacity-90'}`}
          >
            {isAdded ? 'Adicionado!' : 'Comprar'}
          </Button>
          <Button
            variant="outline"
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className="h-11 w-11 rounded-xl glass-button border-glass-border p-0"
          >
            <ShoppingCart className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}

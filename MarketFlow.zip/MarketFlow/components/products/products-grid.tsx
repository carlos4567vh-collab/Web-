"use client"

import { useStore } from '@/lib/store-context'
import { ProductCard } from './product-card'

export function ProductsGrid() {
  const { products, searchQuery } = useStore()

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-foreground">
              {searchQuery ? `Resultados para "${searchQuery}"` : 'Nossos Sabonetes'}
            </h2>
            <p className="text-muted-foreground mt-1">
              {filteredProducts.length} produto{filteredProducts.length !== 1 ? 's' : ''} encontrado{filteredProducts.length !== 1 ? 's' : ''}
            </p>
          </div>
          
          {/* Filter Tags */}
          <div className="hidden md:flex gap-2">
            {['Todos', 'Promoção', 'Novidades', 'Premium'].map((filter) => (
              <button
                key={filter}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300
                           ${filter === 'Todos' 
                             ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg' 
                             : 'glass-button hover:bg-muted/50'}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-muted/50 flex items-center justify-center">
              <span className="text-4xl">🧼</span>
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Nenhum produto encontrado
            </h3>
            <p className="text-muted-foreground">
              Tente buscar por outro termo ou navegue pelas categorias
            </p>
          </div>
        )}
      </div>
    </section>
  )
}

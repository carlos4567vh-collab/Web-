"use client"

import { useStore } from '@/lib/store-context'
import { AnimatedBackground } from '@/components/auth/animated-background'
import { LoginForm } from '@/components/auth/login-form'
import { RegisterForm } from '@/components/auth/register-form'
import { ForgotPasswordForm } from '@/components/auth/forgot-password-form'
import { Verify2FAForm } from '@/components/auth/verify-2fa-form'
import { Header } from '@/components/layout/header'
import { Sidebar } from '@/components/layout/sidebar'
import { Footer } from '@/components/layout/footer'
import { PromoBanners } from '@/components/products/promo-banners'
import { ProductsGrid } from '@/components/products/products-grid'
import { CartDrawer } from '@/components/cart/cart-drawer'
import { SellerChat } from '@/components/features/seller-chat'
import { SupportChat } from '@/components/features/support-chat'
import { LiveStream } from '@/components/features/live-stream'
import { AITool } from '@/components/features/ai-tool'

export function MainApp() {
  const { currentView } = useStore()

  // Auth views
  if (currentView === 'login') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <AnimatedBackground />
        <LoginForm />
      </div>
    )
  }

  if (currentView === 'register') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <AnimatedBackground />
        <RegisterForm />
      </div>
    )
  }

  if (currentView === 'forgot-password') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <AnimatedBackground />
        <ForgotPasswordForm />
      </div>
    )
  }

  if (currentView === 'verify-2fa') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <AnimatedBackground />
        <Verify2FAForm />
      </div>
    )
  }

  // Main app view
  return (
    <div className="min-h-screen flex flex-col">
      <AnimatedBackground />
      
      {/* Header */}
      <Header />
      
      {/* Sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <main className="flex-1">
        <PromoBanners />
        <ProductsGrid />
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* Modals & Drawers */}
      <CartDrawer />
      <SellerChat />
      <SupportChat />
      <LiveStream />
      <AITool />
    </div>
  )
}

"use client"

import { useStore } from '@/lib/store-context'
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function CartDrawer() {
  const { 
    isCartOpen, 
    setIsCartOpen, 
    cart, 
    cartTotal, 
    cartCount,
    updateQuantity, 
    removeFromCart,
    clearCart
  } = useStore()

  if (!isCartOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50"
        onClick={() => setIsCartOpen(false)}
      />

      {/* Drawer */}
      <div className="fixed top-0 right-0 h-full w-full max-w-md z-50 transform transition-transform duration-300">
        <div className="h-full glass-card rounded-none rounded-l-3xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-glass-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary 
                            flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-semibold text-foreground">Carrinho</h2>
                <p className="text-sm text-muted-foreground">
                  {cartCount} {cartCount === 1 ? 'item' : 'itens'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 rounded-xl glass-button hover:scale-105 transition-all"
            >
              <X className="w-5 h-5 text-foreground" />
            </button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-8">
                <div className="w-20 h-20 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                  <ShoppingBag className="w-10 h-10 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Carrinho vazio
                </h3>
                <p className="text-muted-foreground mb-6">
                  Adicione produtos para começar suas compras
                </p>
                <Button
                  onClick={() => setIsCartOpen(false)}
                  className="bg-gradient-to-r from-primary to-secondary text-primary-foreground 
                           rounded-xl font-semibold"
                >
                  Continuar Comprando
                </Button>
              </div>
            ) : (
              <ul className="space-y-4">
                {cart.map((item) => (
                  <li 
                    key={item.id} 
                    className="glass-card p-4 flex gap-4 animate-in slide-in-from-right duration-300"
                  >
                    {/* Image */}
                    <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-foreground line-clamp-1">{item.name}</h4>
                      <p className="text-sm text-muted-foreground">{item.category}</p>
                      <p className="font-semibold text-foreground mt-1">
                        R$ {item.price.toFixed(2).replace('.', ',')}
                      </p>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-3 mt-2">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-8 h-8 rounded-lg glass-button flex items-center justify-center 
                                     hover:bg-muted/50 transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center font-medium text-foreground">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-8 h-8 rounded-lg glass-button flex items-center justify-center 
                                     hover:bg-muted/50 transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-2 rounded-lg text-destructive hover:bg-destructive/10 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Item Total */}
                    <div className="text-right">
                      <p className="font-bold text-foreground">
                        R$ {(item.price * item.quantity).toFixed(2).replace('.', ',')}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Footer */}
          {cart.length > 0 && (
            <div className="p-4 border-t border-glass-border space-y-4">
              {/* Subtotal */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Subtotal</span>
                  <span>R$ {cartTotal.toFixed(2).replace('.', ',')}</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Frete</span>
                  <span className={cartTotal >= 99 ? 'text-green-600' : ''}>
                    {cartTotal >= 99 ? 'Grátis' : 'R$ 15,00'}
                  </span>
                </div>
                <div className="h-px bg-glass-border" />
                <div className="flex justify-between font-semibold text-lg text-foreground">
                  <span>Total</span>
                  <span>R$ {(cartTotal + (cartTotal >= 99 ? 0 : 15)).toFixed(2).replace('.', ',')}</span>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <Button 
                  className="w-full h-12 bg-gradient-to-r from-primary to-secondary text-primary-foreground 
                           rounded-xl font-semibold shadow-lg hover:opacity-90 transition-opacity"
                >
                  Finalizar Compra
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsCartOpen(false)}
                    className="flex-1 h-10 rounded-xl glass-button border-glass-border"
                  >
                    Continuar Comprando
                  </Button>
                  <Button
                    variant="outline"
                    onClick={clearCart}
                    className="h-10 px-4 rounded-xl glass-button border-glass-border text-destructive 
                             hover:bg-destructive/10"
                  >
                    Limpar
                  </Button>
                </div>
              </div>

              {/* Frete grátis progress */}
              {cartTotal < 99 && (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground text-center">
                    Faltam <span className="font-semibold text-primary">R$ {(99 - cartTotal).toFixed(2).replace('.', ',')}</span> para frete grátis!
                  </p>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((cartTotal / 99) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

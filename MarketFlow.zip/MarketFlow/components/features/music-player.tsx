"use client"

import { useRef, useEffect, useState } from 'react'
import { useStore } from '@/lib/store-context'
import { Play, Pause, SkipForward, Lock, Unlock, Film, X } from 'lucide-react'

export function MusicPlayer() {
  const { 
    currentTrack, 
    isPlaying, 
    setIsPlaying, 
    isLocked, 
    setIsLocked,
    showVideo,
    setShowVideo,
    nextTrack,
    playlist
  } = useStore()

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [progress, setProgress] = useState(0)
  const [duration, setDuration] = useState(0)

  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(() => setIsPlaying(false))
      } else {
        audioRef.current.pause()
      }
    }
  }, [isPlaying, currentTrack, setIsPlaying])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const handleTimeUpdate = () => {
      setProgress(audio.currentTime)
    }

    const handleLoadedMetadata = () => {
      setDuration(audio.duration)
    }

    const handleEnded = () => {
      if (isLocked) {
        audio.currentTime = 0
        audio.play()
      } else {
        nextTrack()
      }
    }

    audio.addEventListener('timeupdate', handleTimeUpdate)
    audio.addEventListener('loadedmetadata', handleLoadedMetadata)
    audio.addEventListener('ended', handleEnded)

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate)
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata)
      audio.removeEventListener('ended', handleEnded)
    }
  }, [isLocked, nextTrack])

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, '0')}`
  }

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioRef.current || !duration) return
    const rect = e.currentTarget.getBoundingClientRect()
    const percent = (e.clientX - rect.left) / rect.width
    audioRef.current.currentTime = percent * duration
  }

  if (!currentTrack) return null

  return (
    <div className="space-y-4">
      {/* Audio Element */}
      <audio ref={audioRef} src={currentTrack.audioUrl} />

      {/* Main Display Button - Shows current track info */}
      <div className="glass-card p-4 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
            <img 
              src={currentTrack.cover} 
              alt={currentTrack.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-foreground truncate">{currentTrack.title}</h4>
            <p className="text-sm text-muted-foreground truncate">{currentTrack.artist}</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-4 space-y-1">
          <div 
            className="h-1.5 rounded-full bg-muted cursor-pointer overflow-hidden"
            onClick={handleProgressClick}
          >
            <div 
              className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-100"
              style={{ width: duration ? `${(progress / duration) * 100}%` : '0%' }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{formatTime(progress)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>
      </div>

      {/* Control Buttons - Glassmorphism style */}
      <div className="grid grid-cols-2 gap-3">
        {/* Top Row */}
        {/* Lock Button - Top Left */}
        <button
          onClick={() => setIsLocked(!isLocked)}
          className={`h-14 rounded-2xl glass-button flex items-center justify-center gap-2 
                     transition-all duration-300 hover:scale-105
                     ${isLocked ? 'bg-primary/20 text-primary border-primary/30' : ''}`}
        >
          {isLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
          <span className="text-sm font-medium">{isLocked ? 'Travado' : 'Travar'}</span>
        </button>

        {/* Play/Pause Button - Top Right */}
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className={`h-14 rounded-2xl glass-button flex items-center justify-center gap-2 
                     transition-all duration-300 hover:scale-105
                     ${isPlaying 
                       ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-lg' 
                       : ''}`}
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          <span className="text-sm font-medium">{isPlaying ? 'Pausar' : 'Tocar'}</span>
        </button>

        {/* Bottom Row */}
        {/* Video Button - Bottom Left */}
        <button
          onClick={() => setShowVideo(!showVideo)}
          className={`h-14 rounded-2xl glass-button flex items-center justify-center gap-2 
                     transition-all duration-300 hover:scale-105
                     ${showVideo ? 'bg-secondary/20 text-secondary border-secondary/30' : ''}`}
        >
          <Film className="w-5 h-5" />
          <span className="text-sm font-medium">Clipe</span>
        </button>

        {/* Next Track Button - Bottom Right (Blue) */}
        <button
          onClick={nextTrack}
          className="h-14 rounded-2xl glass-button flex items-center justify-center gap-2 
                   bg-accent/20 text-accent border-accent/30 
                   transition-all duration-300 hover:scale-105 hover:bg-accent/30"
        >
          <SkipForward className="w-5 h-5" />
          <span className="text-sm font-medium">Próxima</span>
        </button>
      </div>

      {/* Video Player Panel */}
      {showVideo && currentTrack.videoUrl && (
        <div className="glass-card p-3 rounded-2xl space-y-2 animate-in slide-in-from-bottom duration-300">
          <div className="flex items-center justify-between">
            <h5 className="text-sm font-semibold text-foreground">Clipe da Música</h5>
            <button
              onClick={() => setShowVideo(false)}
              className="p-1 rounded-lg hover:bg-muted/50 transition-colors"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
          <div className="aspect-video rounded-xl overflow-hidden bg-foreground/5">
            <iframe
              src={currentTrack.videoUrl}
              title={currentTrack.title}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      )}

      {/* Playlist */}
      <div className="space-y-2">
        <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Playlist
        </h5>
        <div className="space-y-1 max-h-40 overflow-y-auto">
          {playlist.map((track) => (
            <button
              key={track.id}
              onClick={() => {
                const { setCurrentTrack } = useStore.getState()
                setCurrentTrack(track)
                setIsPlaying(true)
              }}
              className={`w-full flex items-center gap-3 p-2 rounded-xl transition-all duration-200
                         ${track.id === currentTrack.id 
                           ? 'bg-primary/10 border border-primary/20' 
                           : 'hover:bg-muted/50'}`}
            >
              <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0">
                <img 
                  src={track.cover} 
                  alt={track.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <p className={`text-sm font-medium truncate 
                              ${track.id === currentTrack.id ? 'text-primary' : 'text-foreground'}`}>
                  {track.title}
                </p>
                <p className="text-xs text-muted-foreground truncate">{track.artist}</p>
              </div>
              {track.id === currentTrack.id && isPlaying && (
                <div className="flex gap-0.5">
                  {[1, 2, 3].map((i) => (
                    <div 
                      key={i}
                      className="w-1 bg-primary rounded-full animate-pulse"
                      style={{ 
                        height: `${8 + Math.random() * 8}px`,
                        animationDelay: `${i * 0.1}s`
                      }}
                    />
                  ))}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

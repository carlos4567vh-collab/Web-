"use client"

import { useState, useRef, useEffect } from 'react'
import { useStore } from '@/lib/store-context'
import { X, Send, MessageCircle, User, Store } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export function SellerChat() {
  const { isChatOpen, setIsChatOpen, sellerMessages, addSellerMessage } = useStore()
  const [message, setMessage] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [sellerMessages])

  const handleSend = () => {
    if (!message.trim()) return
    addSellerMessage(message, 'user')
    setMessage('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  if (!isChatOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50"
        onClick={() => setIsChatOpen(false)}
      />

      {/* Chat Window */}
      <div className="fixed bottom-4 right-4 w-full max-w-md h-[600px] z-50 
                     animate-in slide-in-from-bottom-4 duration-300">
        <div className="h-full glass-card rounded-3xl overflow-hidden flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-4 border-b border-glass-border bg-gradient-to-r from-primary/10 to-secondary/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary 
                              flex items-center justify-center shadow-lg">
                  <Store className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Chat com Vendedor</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-sm text-muted-foreground">Online</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsChatOpen(false)}
                className="p-2 rounded-xl glass-button hover:scale-105 transition-all"
              >
                <X className="w-5 h-5 text-foreground" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {sellerMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
                               ${msg.sender === 'user' 
                                 ? 'bg-primary text-primary-foreground' 
                                 : 'bg-secondary text-secondary-foreground'}`}>
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Store className="w-4 h-4" />}
                </div>
                <div className={`max-w-[70%] ${msg.sender === 'user' ? 'text-right' : ''}`}>
                  <div className={`px-4 py-3 rounded-2xl ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-tr-sm'
                      : 'glass-card rounded-tl-sm'
                  }`}>
                    <p className="text-sm">{msg.content}</p>
                  </div>
                  <span className="text-xs text-muted-foreground mt-1 block">
                    {msg.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-glass-border">
            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Digite sua mensagem..."
                className="flex-1 h-12 rounded-xl glass-button border-glass-border"
              />
              <Button
                onClick={handleSend}
                disabled={!message.trim()}
                className="h-12 w-12 rounded-xl bg-gradient-to-r from-primary to-secondary 
                         text-primary-foreground hover:opacity-90 transition-opacity p-0"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

"use client"

import { useState, useRef } from 'react'
import { useStore } from '@/lib/store-context'
import { X, Upload, Sparkles, Wand2, Download, RotateCcw, Sun, Contrast, Palette, Zap } from 'lucide-react'
import { Button } from '@/components/ui/button'

const filters = [
  { id: 'bright', name: 'Brilho', icon: Sun, style: 'brightness(1.2) contrast(1.1)' },
  { id: 'contrast', name: 'Contraste', icon: Contrast, style: 'contrast(1.3) saturate(1.1)' },
  { id: 'warm', name: 'Quente', icon: Palette, style: 'sepia(0.3) saturate(1.2) brightness(1.05)' },
  { id: 'cool', name: 'Frio', icon: Zap, style: 'saturate(0.8) hue-rotate(20deg) brightness(1.1)' },
  { id: 'vivid', name: 'Vívido', icon: Sparkles, style: 'saturate(1.5) contrast(1.1) brightness(1.05)' },
  { id: 'professional', name: 'Profissional', icon: Wand2, style: 'contrast(1.15) saturate(1.1) brightness(1.08)' },
]

export function AITool() {
  const { isAIToolOpen, setIsAIToolOpen } = useStore()
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string)
        setSelectedFilter(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleApplyFilter = (filterId: string) => {
    setIsProcessing(true)
    setTimeout(() => {
      setSelectedFilter(filterId)
      setIsProcessing(false)
    }, 1000)
  }

  const handleAutoEnhance = () => {
    setIsProcessing(true)
    setTimeout(() => {
      setSelectedFilter('professional')
      setIsProcessing(false)
    }, 2000)
  }

  const handleReset = () => {
    setSelectedFilter(null)
  }

  const handleDownload = () => {
    if (!uploadedImage) return
    const link = document.createElement('a')
    link.download = 'produto-melhorado.jpg'
    link.href = uploadedImage
    link.click()
  }

  const currentFilter = filters.find(f => f.id === selectedFilter)

  if (!isAIToolOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-foreground/40 backdrop-blur-md z-50"
        onClick={() => setIsAIToolOpen(false)}
      />

      {/* Modal */}
      <div className="fixed inset-4 md:inset-8 lg:inset-16 z-50 animate-in zoom-in-95 duration-300">
        <div className="h-full glass-card rounded-3xl overflow-hidden flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-4 border-b border-glass-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary 
                            flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="font-semibold text-foreground">Ferramenta IA para Vendedores</h2>
                <p className="text-sm text-muted-foreground">Melhore suas fotos de produtos automaticamente</p>
              </div>
            </div>
            <button
              onClick={() => setIsAIToolOpen(false)}
              className="p-2 rounded-xl glass-button hover:scale-105 transition-all"
            >
              <X className="w-5 h-5 text-foreground" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
            {/* Image Area */}
            <div className="flex-1 p-6 flex items-center justify-center">
              {uploadedImage ? (
                <div className="relative max-w-full max-h-full">
                  <img
                    src={uploadedImage}
                    alt="Produto"
                    className="max-w-full max-h-[400px] lg:max-h-[500px] rounded-2xl shadow-2xl object-contain transition-all duration-500"
                    style={{ filter: currentFilter?.style || 'none' }}
                  />
                  {isProcessing && (
                    <div className="absolute inset-0 bg-foreground/50 rounded-2xl flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/20 
                                      flex items-center justify-center animate-pulse">
                          <Wand2 className="w-8 h-8 text-primary animate-spin" />
                        </div>
                        <p className="text-background font-medium">Processando com IA...</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div 
                  className="w-full max-w-md aspect-square glass-card rounded-2xl flex flex-col items-center 
                           justify-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <div className="w-20 h-20 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                    <Upload className="w-10 h-10 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Envie uma foto do produto
                  </h3>
                  <p className="text-muted-foreground text-center max-w-xs">
                    Clique ou arraste uma imagem para aplicar melhorias automáticas com IA
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              )}
            </div>

            {/* Controls Sidebar */}
            <div className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-glass-border p-4 space-y-6 overflow-y-auto">
              {/* Upload New */}
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="w-full h-12 rounded-xl glass-button border-glass-border"
                >
                  <Upload className="w-5 h-5 mr-2" />
                  {uploadedImage ? 'Trocar Imagem' : 'Enviar Imagem'}
                </Button>
              </div>

              {uploadedImage && (
                <>
                  {/* Auto Enhance */}
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Melhoria Automática</h4>
                    <Button
                      onClick={handleAutoEnhance}
                      disabled={isProcessing}
                      className="w-full h-12 rounded-xl bg-gradient-to-r from-primary to-secondary 
                               text-primary-foreground font-semibold"
                    >
                      <Wand2 className="w-5 h-5 mr-2" />
                      Melhorar com IA
                    </Button>
                  </div>

                  {/* Manual Filters */}
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-3">Filtros Manuais</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {filters.map((filter) => (
                        <button
                          key={filter.id}
                          onClick={() => handleApplyFilter(filter.id)}
                          disabled={isProcessing}
                          className={`p-3 rounded-xl flex flex-col items-center gap-2 transition-all
                                     ${selectedFilter === filter.id 
                                       ? 'bg-primary/20 border-2 border-primary' 
                                       : 'glass-button hover:bg-muted/50'}`}
                        >
                          <filter.icon className={`w-5 h-5 ${selectedFilter === filter.id ? 'text-primary' : 'text-muted-foreground'}`} />
                          <span className={`text-xs font-medium ${selectedFilter === filter.id ? 'text-primary' : 'text-foreground'}`}>
                            {filter.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <Button
                      onClick={handleReset}
                      variant="outline"
                      disabled={!selectedFilter || isProcessing}
                      className="w-full h-10 rounded-xl glass-button border-glass-border"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Resetar
                    </Button>
                    <Button
                      onClick={handleDownload}
                      disabled={isProcessing}
                      className="w-full h-10 rounded-xl bg-green-500 hover:bg-green-600 text-white"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Baixar Imagem
                    </Button>
                  </div>

                  {/* Tips */}
                  <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
                    <h5 className="text-sm font-semibold text-primary mb-2">Dicas para melhores resultados</h5>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>- Use fotos com boa iluminação natural</li>
                      <li>- Centralize o produto na imagem</li>
                      <li>- Prefira fundos neutros ou brancos</li>
                      <li>- Imagens de alta resolução ficam melhores</li>
                    </ul>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

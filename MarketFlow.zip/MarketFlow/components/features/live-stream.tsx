"use client"

import { useState } from 'react'
import { useStore } from '@/lib/store-context'
import { X, Video, VideoOff, Mic, MicOff, Users, ShoppingBag, Heart, MessageCircle, Share2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

const featuredProducts = [
  { id: 1, name: 'Sabonete Lavanda', price: 18.90, image: 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?w=100&h=100&fit=crop' },
  { id: 2, name: 'Sabonete Rosa Mosqueta', price: 22.90, image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=100&h=100&fit=crop' },
  { id: 3, name: 'Sabonete Karité', price: 26.90, image: 'https://images.unsplash.com/photo-1617897903246-719242758050?w=100&h=100&fit=crop' },
]

export function LiveStream() {
  const { isLiveOpen, setIsLiveOpen, addToCart, products } = useStore()
  const [isStreaming, setIsStreaming] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [viewers] = useState(Math.floor(Math.random() * 500) + 100)
  const [likes, setLikes] = useState(Math.floor(Math.random() * 1000) + 500)

  if (!isLiveOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-foreground/40 backdrop-blur-md z-50"
        onClick={() => setIsLiveOpen(false)}
      />

      {/* Live Stream Modal */}
      <div className="fixed inset-4 md:inset-8 z-50 animate-in zoom-in-95 duration-300">
        <div className="h-full glass-card rounded-3xl overflow-hidden flex flex-col lg:flex-row shadow-2xl">
          {/* Video Area */}
          <div className="flex-1 relative bg-foreground/90 flex items-center justify-center">
            {isStreaming ? (
              <>
                {/* Live Video Placeholder */}
                <div className="absolute inset-0">
                  <img 
                    src="https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=1200&h=800&fit=crop"
                    alt="Live stream"
                    className="w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-transparent to-foreground/20" />
                </div>

                {/* Live Badge */}
                <div className="absolute top-4 left-4 flex items-center gap-3">
                  <span className="px-3 py-1.5 rounded-full bg-red-500 text-white text-sm font-bold 
                                 flex items-center gap-2 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-white" />
                    AO VIVO
                  </span>
                  <span className="px-3 py-1.5 rounded-full bg-foreground/50 backdrop-blur-sm text-background 
                                 text-sm font-medium flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    {viewers}
                  </span>
                </div>

                {/* Streamer Info */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary 
                                  flex items-center justify-center border-2 border-background">
                      <span className="text-lg font-bold text-primary-foreground">SB</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-background">SoapBubble Oficial</h3>
                      <p className="text-sm text-background/70">Apresentando nossa coleção de verão!</p>
                    </div>
                  </div>
                </div>

                {/* Engagement Actions */}
                <div className="absolute right-4 bottom-24 flex flex-col gap-4">
                  <button 
                    onClick={() => setLikes(l => l + 1)}
                    className="w-12 h-12 rounded-full bg-background/20 backdrop-blur-sm 
                             flex items-center justify-center hover:bg-red-500/50 transition-colors"
                  >
                    <Heart className="w-6 h-6 text-background fill-red-500" />
                  </button>
                  <span className="text-center text-background text-sm font-medium">{likes}</span>
                  <button className="w-12 h-12 rounded-full bg-background/20 backdrop-blur-sm 
                                   flex items-center justify-center hover:bg-background/30 transition-colors">
                    <MessageCircle className="w-6 h-6 text-background" />
                  </button>
                  <button className="w-12 h-12 rounded-full bg-background/20 backdrop-blur-sm 
                                   flex items-center justify-center hover:bg-background/30 transition-colors">
                    <Share2 className="w-6 h-6 text-background" />
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center p-8">
                <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-muted/50 flex items-center justify-center">
                  <Video className="w-12 h-12 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-bold text-background mb-2">Área de Lives</h3>
                <p className="text-background/70 mb-6 max-w-sm">
                  Aqui os vendedores podem transmitir ao vivo e mostrar seus produtos em tempo real
                </p>
                <Button
                  onClick={() => setIsStreaming(true)}
                  className="bg-red-500 hover:bg-red-600 text-white rounded-xl font-semibold"
                >
                  Iniciar Transmissão
                </Button>
              </div>
            )}

            {/* Close Button */}
            <button
              onClick={() => setIsLiveOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-background/20 backdrop-blur-sm 
                       hover:bg-background/30 transition-colors"
            >
              <X className="w-6 h-6 text-background" />
            </button>
          </div>

          {/* Sidebar - Products & Controls */}
          <div className="w-full lg:w-80 flex flex-col border-t lg:border-t-0 lg:border-l border-glass-border">
            {/* Controls (for streamer) */}
            {isStreaming && (
              <div className="p-4 border-b border-glass-border">
                <h4 className="text-sm font-semibold text-foreground mb-3">Controles da Live</h4>
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsVideoOn(!isVideoOn)}
                    className={`flex-1 h-10 rounded-xl flex items-center justify-center gap-2 
                               transition-all ${isVideoOn ? 'glass-button' : 'bg-red-500/20 text-red-500'}`}
                  >
                    {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                    <span className="text-sm">Vídeo</span>
                  </button>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className={`flex-1 h-10 rounded-xl flex items-center justify-center gap-2 
                               transition-all ${!isMuted ? 'glass-button' : 'bg-red-500/20 text-red-500'}`}
                  >
                    {!isMuted ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                    <span className="text-sm">Áudio</span>
                  </button>
                </div>
              </div>
            )}

            {/* Featured Products */}
            <div className="flex-1 overflow-y-auto p-4">
              <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <ShoppingBag className="w-4 h-4" />
                Produtos em Destaque
              </h4>
              <div className="space-y-3">
                {featuredProducts.map((product) => {
                  const fullProduct = products.find(p => p.id === product.id) || {
                    ...product,
                    description: '',
                    rating: 4.5,
                    reviews: 100,
                    category: 'Sabonete',
                    inStock: true
                  }
                  return (
                    <div key={product.id} className="glass-card p-3 flex gap-3">
                      <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0">
                        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h5 className="font-medium text-foreground text-sm truncate">{product.name}</h5>
                        <p className="text-lg font-bold text-primary">
                          R$ {product.price.toFixed(2).replace('.', ',')}
                        </p>
                        <Button
                          size="sm"
                          onClick={() => addToCart(fullProduct as any)}
                          className="mt-1 h-7 text-xs bg-gradient-to-r from-primary to-secondary 
                                   text-primary-foreground rounded-lg"
                        >
                          Adicionar
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            {/* End Stream Button */}
            {isStreaming && (
              <div className="p-4 border-t border-glass-border">
                <Button
                  onClick={() => setIsStreaming(false)}
                  variant="destructive"
                  className="w-full rounded-xl"
                >
                  Encerrar Live
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

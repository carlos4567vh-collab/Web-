"use client"

import { useState, useRef, useEffect } from 'react'
import { useStore } from '@/lib/store-context'
import { X, Send, Headphones, User, MessageSquare } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

const quickReplies = [
  'Rastrear meu pedido',
  'Política de troca',
  'Formas de pagamento',
  'Falar com atendente'
]

export function SupportChat() {
  const { isSupportChatOpen, setIsSupportChatOpen, supportMessages, addSupportMessage } = useStore()
  const [message, setMessage] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [supportMessages])

  const handleSend = (text?: string) => {
    const msgToSend = text || message
    if (!msgToSend.trim()) return
    addSupportMessage(msgToSend, 'user')
    setMessage('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  if (!isSupportChatOpen) return null

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50"
        onClick={() => setIsSupportChatOpen(false)}
      />

      {/* Chat Window */}
      <div className="fixed bottom-4 right-4 w-full max-w-md h-[600px] z-50 
                     animate-in slide-in-from-bottom-4 duration-300">
        <div className="h-full glass-card rounded-3xl overflow-hidden flex flex-col shadow-2xl">
          {/* Header */}
          <div className="p-4 border-b border-glass-border bg-gradient-to-r from-accent/10 to-primary/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-accent to-primary 
                              flex items-center justify-center shadow-lg">
                  <Headphones className="w-6 h-6 text-accent-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Suporte SoapBubble</h3>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-sm text-muted-foreground">Disponível 24h</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsSupportChatOpen(false)}
                className="p-2 rounded-xl glass-button hover:scale-105 transition-all"
              >
                <X className="w-5 h-5 text-foreground" />
              </button>
            </div>
          </div>

          {/* Quick Replies */}
          <div className="p-3 border-b border-glass-border">
            <p className="text-xs text-muted-foreground mb-2">Perguntas frequentes:</p>
            <div className="flex flex-wrap gap-2">
              {quickReplies.map((reply) => (
                <button
                  key={reply}
                  onClick={() => handleSend(reply)}
                  className="px-3 py-1.5 rounded-full text-xs font-medium glass-button 
                           hover:bg-primary/10 hover:text-primary transition-all"
                >
                  {reply}
                </button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {supportMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
                               ${msg.sender === 'user' 
                                 ? 'bg-primary text-primary-foreground' 
                                 : 'bg-accent text-accent-foreground'}`}>
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Headphones className="w-4 h-4" />}
                </div>
                <div className={`max-w-[70%] ${msg.sender === 'user' ? 'text-right' : ''}`}>
                  <div className={`px-4 py-3 rounded-2xl ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-tr-sm'
                      : 'glass-card rounded-tl-sm'
                  }`}>
                    <p className="text-sm">{msg.content}</p>
                  </div>
                  <span className="text-xs text-muted-foreground mt-1 block">
                    {msg.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-glass-border">
            <div className="flex gap-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Como podemos ajudar?"
                className="flex-1 h-12 rounded-xl glass-button border-glass-border"
              />
              <Button
                onClick={() => handleSend()}
                disabled={!message.trim()}
                className="h-12 w-12 rounded-xl bg-gradient-to-r from-accent to-primary 
                         text-accent-foreground hover:opacity-90 transition-opacity p-0"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

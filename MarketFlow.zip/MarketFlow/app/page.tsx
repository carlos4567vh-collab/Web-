"use client"

import { StoreProvider } from '@/lib/store-context'
import { MainApp } from '@/components/main-app'

export default function Home() {
  return (
    <StoreProvider>
      <MainApp />
    </StoreProvider>
  )
}

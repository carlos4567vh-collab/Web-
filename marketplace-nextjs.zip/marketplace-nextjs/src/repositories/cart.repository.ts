import { prisma } from "@/lib/prisma";

export class CartRepository {
  static async findOrCreate(userId: string) {
    let cart = await prisma.cart.findUnique({
      where: { userId },
      include: { items: { include: { product: { include: { seller: { select: { id: true, name: true } } } } } } },
    });
    if (!cart) {
      cart = await prisma.cart.create({
        data: { userId },
        include: { items: { include: { product: { include: { seller: { select: { id: true, name: true } } } } } } },
      });
    }
    return cart;
  }

  static async addItem(userId: string, productId: string, quantity: number) {
    const cart = await this.findOrCreate(userId);
    const existing = cart.items.find((i) => i.productId === productId);

    if (existing) {
      await prisma.cartItem.update({
        where: { id: existing.id },
        data: { quantity: existing.quantity + quantity },
      });
    } else {
      await prisma.cartItem.create({
        data: { cartId: cart.id, productId, quantity },
      });
    }

    return this.findOrCreate(userId);
  }

  static async updateItem(userId: string, productId: string, quantity: number) {
    const cart = await this.findOrCreate(userId);
    const item = cart.items.find((i) => i.productId === productId);
    if (!item) throw new Error("Item não encontrado no carrinho");

    if (quantity <= 0) {
      await prisma.cartItem.delete({ where: { id: item.id } });
    } else {
      await prisma.cartItem.update({ where: { id: item.id }, data: { quantity } });
    }

    return this.findOrCreate(userId);
  }

  static async removeItem(userId: string, productId: string) {
    const cart = await this.findOrCreate(userId);
    const item = cart.items.find((i) => i.productId === productId);
    if (item) await prisma.cartItem.delete({ where: { id: item.id } });
    return this.findOrCreate(userId);
  }

  static async clear(userId: string) {
    const cart = await prisma.cart.findUnique({ where: { userId } });
    if (cart) await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
  }
}

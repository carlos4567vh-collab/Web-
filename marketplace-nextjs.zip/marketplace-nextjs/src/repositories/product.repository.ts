import { prisma } from "@/lib/prisma";
import { ProductFilters, PaginatedResponse } from "@/types";
import { Product, Prisma } from "@prisma/client";

export class ProductRepository {
  static async findMany(filters: ProductFilters): Promise<PaginatedResponse<Product>> {
    const { search, categoryId, minPrice, maxPrice, sortBy, page = 1, limit = 20 } = filters;

    const where: Prisma.ProductWhereInput = { active: true };

    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ];
    }
    if (categoryId) where.categoryId = categoryId;
    if (minPrice !== undefined || maxPrice !== undefined) {
      where.price = {};
      if (minPrice !== undefined) where.price.gte = minPrice;
      if (maxPrice !== undefined) where.price.lte = maxPrice;
    }

    const orderBy: Prisma.ProductOrderByWithRelationInput = (() => {
      switch (sortBy) {
        case "price_asc": return { price: "asc" as const };
        case "price_desc": return { price: "desc" as const };
        case "newest": return { createdAt: "desc" as const };
        default: return { createdAt: "desc" as const };
      }
    })();

    const [data, total] = await Promise.all([
      prisma.product.findMany({
        where,
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
        include: { category: true, seller: { select: { id: true, name: true, image: true } }, reviews: { select: { rating: true } } },
      }),
      prisma.product.count({ where }),
    ]);

    return { data, total, page, totalPages: Math.ceil(total / limit) };
  }

  static async findById(id: string) {
    return prisma.product.findUnique({
      where: { id },
      include: {
        category: true,
        seller: { select: { id: true, name: true, image: true } },
        reviews: { include: { user: { select: { id: true, name: true, image: true } } }, orderBy: { createdAt: "desc" } },
      },
    });
  }

  static async findBySlug(slug: string) {
    return prisma.product.findUnique({
      where: { slug },
      include: {
        category: true,
        seller: { select: { id: true, name: true, image: true } },
        reviews: { include: { user: { select: { id: true, name: true, image: true } } }, orderBy: { createdAt: "desc" } },
      },
    });
  }

  static async create(data: Prisma.ProductCreateInput) {
    return prisma.product.create({ data });
  }

  static async update(id: string, data: Prisma.ProductUpdateInput) {
    return prisma.product.update({ where: { id }, data });
  }

  static async delete(id: string) {
    return prisma.product.update({ where: { id }, data: { active: false } });
  }

  static async findBySeller(sellerId: string) {
    return prisma.product.findMany({
      where: { sellerId },
      include: { category: true, _count: { select: { orderItems: true, reviews: true } } },
      orderBy: { createdAt: "desc" },
    });
  }
}

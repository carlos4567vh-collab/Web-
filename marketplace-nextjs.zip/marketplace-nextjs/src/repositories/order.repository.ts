import { prisma } from "@/lib/prisma";
import { OrderStatus, PaymentStatus } from "@prisma/client";

export class OrderRepository {
  static async create(userId: string, items: { productId: string; quantity: number; price: number }[], total: number, stripeId?: string) {
    return prisma.order.create({
      data: {
        userId,
        total,
        stripeId,
        items: { create: items },
      },
      include: { items: { include: { product: true } } },
    });
  }

  static async findByUser(userId: string) {
    return prisma.order.findMany({
      where: { userId },
      include: { items: { include: { product: true } } },
      orderBy: { createdAt: "desc" },
    });
  }

  static async findById(id: string) {
    return prisma.order.findUnique({
      where: { id },
      include: { items: { include: { product: true } }, user: { select: { id: true, name: true, email: true } } },
    });
  }

  static async updateStatus(id: string, status: OrderStatus) {
    return prisma.order.update({ where: { id }, data: { status } });
  }

  static async updatePaymentStatus(id: string, paymentStatus: PaymentStatus) {
    return prisma.order.update({ where: { id }, data: { paymentStatus } });
  }

  static async findByStripeId(stripeId: string) {
    return prisma.order.findFirst({ where: { stripeId } });
  }
}

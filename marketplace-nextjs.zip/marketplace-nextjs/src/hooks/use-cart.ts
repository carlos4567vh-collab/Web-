"use client";

import { useCallback } from "react";
import { useCartStore } from "@/store/cart-store";
import { toast } from "sonner";

export function useCart() {
  const { items, setItems, setLoading, isLoading, itemCount, total } = useCartStore();

  const fetchCart = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/cart");
      if (res.ok) {
        const data = await res.json();
        setItems(data.items || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoading(false);
    }
  }, [setItems, setLoading]);

  const addItem = useCallback(async (productId: string, quantity = 1) => {
    try {
      const res = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity }),
      });
      if (res.ok) {
        const data = await res.json();
        setItems(data.items || []);
        toast.success("Adicionado ao carrinho");
      }
    } catch {
      toast.error("Erro ao adicionar ao carrinho");
    }
  }, [setItems]);

  const updateQuantity = useCallback(async (productId: string, quantity: number) => {
    try {
      const res = await fetch("/api/cart", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity }),
      });
      if (res.ok) {
        const data = await res.json();
        setItems(data.items || []);
      }
    } catch {
      toast.error("Erro ao atualizar carrinho");
    }
  }, [setItems]);

  const removeItem = useCallback(async (productId: string) => {
    try {
      const res = await fetch("/api/cart", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId }),
      });
      if (res.ok) {
        const data = await res.json();
        setItems(data.items || []);
        toast.success("Item removido");
      }
    } catch {
      toast.error("Erro ao remover item");
    }
  }, [setItems]);

  return { items, isLoading, itemCount: itemCount(), total: total(), fetchCart, addItem, updateQuantity, removeItem };
}

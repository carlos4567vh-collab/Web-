import Redis from "ioredis";

let redis: Redis | null = null;

export function getRedis(): Redis | null {
  if (!process.env.REDIS_URL) return null;
  if (!redis) {
    redis = new Redis(process.env.REDIS_URL);
  }
  return redis;
}

export async function cacheGet<T>(key: string): Promise<T | null> {
  const client = getRedis();
  if (!client) return null;
  const data = await client.get(key);
  return data ? JSON.parse(data) : null;
}

export async function cacheSet(key: string, data: unknown, ttl = 300): Promise<void> {
  const client = getRedis();
  if (!client) return;
  await client.set(key, JSON.stringify(data), "EX", ttl);
}

export async function cacheDel(pattern: string): Promise<void> {
  const client = getRedis();
  if (!client) return;
  const keys = await client.keys(pattern);
  if (keys.length > 0) await client.del(...keys);
}

"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, LoginInput } from "@/lib/validations";
import Link from "next/link";
import { Loader2 } from "lucide-react";

export function LoginForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginInput) => {
    setError("");
    const result = await signIn("credentials", { ...data, redirect: false });
    if (result?.error) {
      setError("Email ou senha inválidos");
    } else {
      router.push("/");
      router.refresh();
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      {error && <div className="p-3 bg-red-50 text-danger text-sm rounded-lg">{error}</div>}

      <div>
        <label className="block text-sm font-medium text-ink mb-1">Email</label>
        <input {...register("email")} type="email" className="input-field" placeholder="seu@email.com" />
        {errors.email && <p className="text-danger text-xs mt-1">{errors.email.message}</p>}
      </div>

      <div>
        <label className="block text-sm font-medium text-ink mb-1">Senha</label>
        <input {...register("password")} type="password" className="input-field" placeholder="••••••••" />
        {errors.password && <p className="text-danger text-xs mt-1">{errors.password.message}</p>}
      </div>

      <div className="flex justify-end">
        <Link href="/reset-password" className="text-sm text-info hover:underline">Esqueceu a senha?</Link>
      </div>

      <button type="submit" disabled={isSubmitting} className="btn-secondary w-full flex items-center justify-center gap-2">
        {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
        Entrar
      </button>

      <p className="text-center text-sm text-ink-muted">
        Não tem uma conta? <Link href="/register" className="text-info hover:underline font-medium">Criar conta</Link>
      </p>
    </form>
  );
}

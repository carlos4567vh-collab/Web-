"use client";

import { ShoppingCart, Loader2 } from "lucide-react";
import { useState } from "react";
import { useCart } from "@/hooks/use-cart";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export function AddToCartButton({ productId, disabled }: { productId: string; disabled?: boolean }) {
  const { addItem } = useCart();
  const { data: session } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleAdd = async () => {
    if (!session) { router.push("/login"); return; }
    setLoading(true);
    await addItem(productId);
    setLoading(false);
  };

  return (
    <button onClick={handleAdd} disabled={disabled || loading} className="btn-secondary w-full flex items-center justify-center gap-2 !py-3 text-base disabled:opacity-50 disabled:cursor-not-allowed">
      {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShoppingCart className="w-5 h-5" />}
      {disabled ? "Produto esgotado" : "Adicionar ao carrinho"}
    </button>
  );
}

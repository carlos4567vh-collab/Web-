import { ProductCard } from "./ProductCard";

interface ProductGridProps {
  products: any[];
}

export function ProductGrid({ products }: ProductGridProps) {
  if (!products.length) {
    return (
      <div className="text-center py-16">
        <p className="text-ink-muted text-lg">Nenhum produto encontrado</p>
        <p className="text-ink-subtle text-sm mt-1">Tente alterar os filtros de busca</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

const SORT_OPTIONS = [
  { value: "newest", label: "Mais recentes" },
  { value: "price_asc", label: "Menor preço" },
  { value: "price_desc", label: "Maior preço" },
  { value: "popular", label: "Mais vendidos" },
];

export function SearchFilters({ categories }: { categories: { id: string; name: string }[] }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [minPrice, setMinPrice] = useState(searchParams.get("minPrice") || "");
  const [maxPrice, setMaxPrice] = useState(searchParams.get("maxPrice") || "");

  const updateParam = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    params.set("page", "1");
    router.push(`/products?${params.toString()}`);
  };

  const applyPrice = () => {
    const params = new URLSearchParams(searchParams.toString());
    if (minPrice) params.set("minPrice", minPrice); else params.delete("minPrice");
    if (maxPrice) params.set("maxPrice", maxPrice); else params.delete("maxPrice");
    params.set("page", "1");
    router.push(`/products?${params.toString()}`);
  };

  return (
    <aside className="space-y-6">
      <div>
        <h3 className="font-semibold text-ink mb-3 text-sm">Categorias</h3>
        <ul className="space-y-1.5">
          <li>
            <button onClick={() => updateParam("categoryId", "")} className="text-sm text-ink-muted hover:text-info transition-colors">
              Todas
            </button>
          </li>
          {categories.map((cat) => (
            <li key={cat.id}>
              <button
                onClick={() => updateParam("categoryId", cat.id)}
                className={`text-sm transition-colors ${searchParams.get("categoryId") === cat.id ? "text-info font-medium" : "text-ink-muted hover:text-info"}`}
              >
                {cat.name}
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h3 className="font-semibold text-ink mb-3 text-sm">Preço</h3>
        <div className="flex gap-2">
          <input type="number" placeholder="Min" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="input-field text-sm !py-1.5 w-20" />
          <span className="text-ink-subtle self-center">-</span>
          <input type="number" placeholder="Max" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="input-field text-sm !py-1.5 w-20" />
        </div>
        <button onClick={applyPrice} className="mt-2 text-xs text-info hover:underline">Aplicar</button>
      </div>

      <div>
        <h3 className="font-semibold text-ink mb-3 text-sm">Ordenar</h3>
        <select onChange={(e) => updateParam("sortBy", e.target.value)} value={searchParams.get("sortBy") || ""} className="input-field text-sm !py-1.5">
          <option value="">Relevância</option>
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
    </aside>
  );
}

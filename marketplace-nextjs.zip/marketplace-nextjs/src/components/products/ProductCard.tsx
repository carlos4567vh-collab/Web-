"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart, Star } from "lucide-react";
import { formatPrice } from "@/lib/utils";

interface ProductCardProps {
  product: {
    id: string;
    title: string;
    slug: string;
    price: number;
    images: string[];
    reviews?: { rating: number }[];
    seller?: { name: string };
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const avgRating = product.reviews?.length
    ? (product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length).toFixed(1)
    : null;

  return (
    <Link href={`/products/${product.slug}`} className="card group overflow-hidden">
      <div className="aspect-square relative bg-surface-muted overflow-hidden">
        <Image
          src={product.images[0] || "/images/placeholder.png"}
          alt={product.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
        />
        <button
          onClick={(e) => { e.preventDefault(); }}
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center hover:bg-white shadow-sm transition-colors"
        >
          <Heart className="w-4 h-4 text-ink-muted" />
        </button>
      </div>
      <div className="p-4">
        <h3 className="text-sm text-ink-muted line-clamp-2 mb-1 group-hover:text-info transition-colors">
          {product.title}
        </h3>
        <p className="text-xl font-bold text-ink">{formatPrice(product.price)}</p>
        <p className="text-xs text-success font-medium mt-1">Frete grátis</p>
        {avgRating && (
          <div className="flex items-center gap-1 mt-2 text-xs text-ink-muted">
            <Star className="w-3.5 h-3.5 fill-brand-500 text-brand-500" />
            <span>{avgRating}</span>
            <span>({product.reviews!.length})</span>
          </div>
        )}
      </div>
    </Link>
  );
}

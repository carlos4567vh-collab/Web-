import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-surface-muted border-t mt-16">
      <div className="container-main py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-ink mb-3">Marketplace</h3>
            <p className="text-sm text-ink-muted">O maior marketplace do Brasil. Compre e venda com segurança e praticidade.</p>
          </div>
          <div>
            <h4 className="font-semibold text-ink mb-3 text-sm">Comprar</h4>
            <ul className="space-y-2 text-sm text-ink-muted">
              <li><Link href="/products" className="hover:text-ink transition-colors">Todos os produtos</Link></li>
              <li><Link href="/products?sortBy=newest" className="hover:text-ink transition-colors">Novidades</Link></li>
              <li><Link href="/products?sortBy=popular" className="hover:text-ink transition-colors">Mais vendidos</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-ink mb-3 text-sm">Vender</h4>
            <ul className="space-y-2 text-sm text-ink-muted">
              <li><Link href="/register" className="hover:text-ink transition-colors">Criar conta</Link></li>
              <li><Link href="/seller/dashboard" className="hover:text-ink transition-colors">Painel do vendedor</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-ink mb-3 text-sm">Ajuda</h4>
            <ul className="space-y-2 text-sm text-ink-muted">
              <li><a href="#" className="hover:text-ink transition-colors">Central de ajuda</a></li>
              <li><a href="#" className="hover:text-ink transition-colors">Termos de uso</a></li>
              <li><a href="#" className="hover:text-ink transition-colors">Política de privacidade</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t mt-8 pt-8 text-center text-sm text-ink-subtle">
          © {new Date().getFullYear()} Marketplace. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}

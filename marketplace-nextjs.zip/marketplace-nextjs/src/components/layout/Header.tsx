"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { Search, ShoppingCart, Heart, User, Menu, X, Package, LayoutDashboard } from "lucide-react";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCartStore } from "@/store/cart-store";

export function Header() {
  const { data: session } = useSession();
  const user = session?.user as any;
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState("");
  const router = useRouter();
  const itemCount = useCartStore((s) => s.items.reduce((sum, i) => sum + i.quantity, 0));

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) router.push(`/products?search=${encodeURIComponent(search.trim())}`);
  };

  return (
    <header className="sticky top-0 z-50 bg-brand-500 shadow-sm">
      <div className="container-main">
        <div className="flex items-center gap-4 py-3">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0 text-xl font-bold text-ink">
            Marketplace
          </Link>

          {/* Search */}
          <form onSubmit={handleSearch} className="hidden sm:flex flex-1 max-w-2xl">
            <div className="relative w-full">
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar produtos, marcas e muito mais..."
                className="w-full py-2 px-4 pr-12 rounded-lg bg-white text-ink text-sm focus:outline-none focus:ring-2 focus:ring-brand-700"
              />
              <button type="submit" className="absolute right-0 top-0 h-full px-4 bg-brand-700 rounded-r-lg hover:bg-brand-800 transition-colors">
                <Search className="w-4 h-4 text-white" />
              </button>
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {session ? (
              <>
                <Link href="/profile/wishlist" className="hidden sm:flex items-center gap-1 text-sm text-ink/80 hover:text-ink transition-colors">
                  <Heart className="w-5 h-5" />
                </Link>
                <Link href="/cart" className="relative flex items-center gap-1 text-sm text-ink/80 hover:text-ink transition-colors">
                  <ShoppingCart className="w-5 h-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-danger text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                      {itemCount}
                    </span>
                  )}
                </Link>
                <div className="hidden sm:flex items-center gap-2">
                  {user?.role === "SELLER" && (
                    <Link href="/seller/dashboard" className="text-sm text-ink/80 hover:text-ink flex items-center gap-1">
                      <Package className="w-4 h-4" /> Vendas
                    </Link>
                  )}
                  {user?.role === "ADMIN" && (
                    <Link href="/admin/dashboard" className="text-sm text-ink/80 hover:text-ink flex items-center gap-1">
                      <LayoutDashboard className="w-4 h-4" /> Admin
                    </Link>
                  )}
                  <Link href="/profile" className="text-sm text-ink/80 hover:text-ink flex items-center gap-1">
                    <User className="w-4 h-4" /> {user?.name?.split(" ")[0]}
                  </Link>
                  <button onClick={() => signOut()} className="text-sm text-ink/60 hover:text-ink transition-colors">
                    Sair
                  </button>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login" className="text-sm font-medium text-ink/80 hover:text-ink">Entrar</Link>
                <Link href="/register" className="btn-secondary text-sm !py-1.5 !px-4">Criar conta</Link>
              </div>
            )}
            <button onClick={() => setMenuOpen(!menuOpen)} className="sm:hidden text-ink">
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        <form onSubmit={handleSearch} className="sm:hidden pb-3">
          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar produtos..."
              className="w-full py-2 px-4 pr-12 rounded-lg bg-white text-ink text-sm focus:outline-none"
            />
            <button type="submit" className="absolute right-0 top-0 h-full px-4 bg-brand-700 rounded-r-lg">
              <Search className="w-4 h-4 text-white" />
            </button>
          </div>
        </form>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="sm:hidden border-t border-brand-600 py-3 space-y-2">
            {session ? (
              <>
                <Link href="/profile" className="block text-sm text-ink/80 py-1">Meu Perfil</Link>
                <Link href="/orders" className="block text-sm text-ink/80 py-1">Meus Pedidos</Link>
                <Link href="/profile/wishlist" className="block text-sm text-ink/80 py-1">Favoritos</Link>
                {user?.role === "SELLER" && <Link href="/seller/dashboard" className="block text-sm text-ink/80 py-1">Painel do Vendedor</Link>}
                {user?.role === "ADMIN" && <Link href="/admin/dashboard" className="block text-sm text-ink/80 py-1">Painel Admin</Link>}
                <button onClick={() => signOut()} className="block text-sm text-ink/60 py-1">Sair</button>
              </>
            ) : (
              <>
                <Link href="/login" className="block text-sm text-ink/80 py-1">Entrar</Link>
                <Link href="/register" className="block text-sm text-ink/80 py-1">Criar conta</Link>
              </>
            )}
          </div>
        )}
      </div>

      {/* Categories bar */}
      <div className="bg-brand-600 hidden sm:block">
        <div className="container-main">
          <nav className="flex items-center gap-6 py-1.5 text-sm text-ink/70">
            <Link href="/products" className="hover:text-ink transition-colors">Todos</Link>
            <Link href="/products?categoryId=electronics" className="hover:text-ink transition-colors">Eletrônicos</Link>
            <Link href="/products?categoryId=fashion" className="hover:text-ink transition-colors">Moda</Link>
            <Link href="/products?categoryId=home" className="hover:text-ink transition-colors">Casa</Link>
            <Link href="/products?categoryId=sports" className="hover:text-ink transition-colors">Esportes</Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

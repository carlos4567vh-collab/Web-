"use client";

import { Star } from "lucide-react";
import { useState } from "react";
import { useSession } from "next-auth/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { reviewSchema, ReviewInput } from "@/lib/validations";
import { formatDate } from "@/lib/utils";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

interface Review {
  id: string;
  rating: number;
  comment: string | null;
  createdAt: string;
  user: { id: string; name: string; image: string | null };
}

export function ReviewList({ reviews, productId }: { reviews: Review[]; productId: string }) {
  const { data: session } = useSession();
  const router = useRouter();
  const [selectedRating, setSelectedRating] = useState(0);
  const { register, handleSubmit, reset, setValue, formState: { isSubmitting } } = useForm<ReviewInput>({
    resolver: zodResolver(reviewSchema),
  });

  const onSubmit = async (data: ReviewInput) => {
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, productId }),
    });
    if (res.ok) {
      toast.success("Avaliação enviada!");
      reset();
      setSelectedRating(0);
      router.refresh();
    } else {
      const json = await res.json();
      toast.error(json.error || "Erro ao enviar avaliação");
    }
  };

  return (
    <div>
      {session && (
        <form onSubmit={handleSubmit(onSubmit)} className="card p-6 mb-8">
          <h3 className="font-semibold text-ink mb-3">Deixe sua avaliação</h3>
          <div className="flex gap-1 mb-3">
            {[1, 2, 3, 4, 5].map((s) => (
              <button key={s} type="button" onClick={() => { setSelectedRating(s); setValue("rating", s); }}>
                <Star className={`w-6 h-6 cursor-pointer transition-colors ${s <= selectedRating ? "fill-brand-500 text-brand-500" : "text-surface-subtle hover:text-brand-300"}`} />
              </button>
            ))}
          </div>
          <input type="hidden" {...register("rating", { valueAsNumber: true })} />
          <textarea {...register("comment")} className="input-field mb-3" rows={3} placeholder="Conte sua experiência (opcional)" />
          <button type="submit" disabled={isSubmitting || !selectedRating} className="btn-secondary !py-2 text-sm disabled:opacity-50">
            Enviar avaliação
          </button>
        </form>
      )}

      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="border-b pb-4">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-sm font-bold text-brand-700">
                {review.user.name[0]}
              </div>
              <span className="font-medium text-sm text-ink">{review.user.name}</span>
              <span className="text-xs text-ink-subtle">{formatDate(review.createdAt)}</span>
            </div>
            <div className="flex gap-0.5 mb-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className={`w-3.5 h-3.5 ${s <= review.rating ? "fill-brand-500 text-brand-500" : "text-surface-subtle"}`} />
              ))}
            </div>
            {review.comment && <p className="text-sm text-ink-muted">{review.comment}</p>}
          </div>
        ))}
        {!reviews.length && <p className="text-sm text-ink-subtle">Nenhuma avaliação ainda. Seja o primeiro!</p>}
      </div>
    </div>
  );
}

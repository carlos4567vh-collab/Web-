import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { ProductGrid } from "@/components/products/ProductGrid";
import { Search, Truck, Shield, CreditCard } from "lucide-react";

export default async function HomePage() {
  const [products, categories] = await Promise.all([
    prisma.product.findMany({
      where: { active: true },
      include: { category: true, reviews: { select: { rating: true } } },
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-r from-brand-400 to-brand-600 py-10 sm:py-16">
        <div className="container-main text-center">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-ink mb-4" style={{ lineHeight: "1.1" }}>
            Encontre tudo o que você precisa
          </h1>
          <p className="text-ink/70 text-lg mb-8 max-w-xl mx-auto">
            Milhares de produtos com os melhores preços. Compre com segurança e frete grátis.
          </p>
          <Link href="/products" className="btn-secondary text-base !px-8 !py-3">
            Ver produtos
          </Link>
        </div>
      </section>

      {/* Benefits */}
      <section className="border-b">
        <div className="container-main py-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Truck, text: "Frete grátis", sub: "Em compras acima de R$99" },
              { icon: Shield, text: "Compra segura", sub: "Seus dados protegidos" },
              { icon: CreditCard, text: "Parcele em até 12x", sub: "Sem juros no cartão" },
              { icon: Search, text: "Milhares de produtos", sub: "Encontre o que precisa" },
            ].map(({ icon: Icon, text, sub }) => (
              <div key={text} className="flex items-center gap-3 text-sm">
                <Icon className="w-8 h-8 text-info flex-shrink-0" />
                <div>
                  <p className="font-semibold text-ink">{text}</p>
                  <p className="text-ink-subtle text-xs">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="container-main py-10">
          <h2 className="text-xl font-bold text-ink mb-6">Categorias</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/products?categoryId=${cat.id}`}
                className="flex-shrink-0 px-5 py-2.5 bg-surface-muted rounded-full text-sm font-medium text-ink-muted hover:bg-brand-100 hover:text-ink transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Products */}
      <section className="container-main py-10">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-ink">Produtos em destaque</h2>
          <Link href="/products" className="text-sm text-info hover:underline">Ver todos →</Link>
        </div>
        <ProductGrid products={products} />
      </section>
    </div>
  );
}

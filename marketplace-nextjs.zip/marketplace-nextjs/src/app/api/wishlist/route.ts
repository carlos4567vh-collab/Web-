import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const wishlist = await prisma.wishlist.findMany({
      where: { userId: (session.user as any).id },
      include: { product: { include: { category: true } } },
    });
    return NextResponse.json(wishlist);
  } catch {
    return NextResponse.json({ error: "Erro" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { productId } = await req.json();
    const userId = (session.user as any).id;

    const existing = await prisma.wishlist.findUnique({ where: { userId_productId: { userId, productId } } });

    if (existing) {
      await prisma.wishlist.delete({ where: { id: existing.id } });
      return NextResponse.json({ added: false });
    }

    await prisma.wishlist.create({ data: { userId, productId } });
    return NextResponse.json({ added: true });
  } catch {
    return NextResponse.json({ error: "Erro" }, { status: 500 });
  }
}

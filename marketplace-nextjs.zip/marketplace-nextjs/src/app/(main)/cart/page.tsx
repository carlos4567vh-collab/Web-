"use client";

import { useEffect } from "react";
import { useCart } from "@/hooks/use-cart";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { formatPrice } from "@/lib/utils";
import { Trash2, Plus, Minus, ShoppingBag, Loader2 } from "lucide-react";
import { useState } from "react";

export default function CartPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const { items, isLoading, total, fetchCart, updateQuantity, removeItem } = useCart();
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  useEffect(() => {
    if (!session) { router.push("/login"); return; }
    fetchCart();
  }, [session, router, fetchCart]);

  const handleCheckout = async () => {
    setCheckoutLoading(true);
    try {
      const res = await fetch("/api/checkout", { method: "POST" });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
    } catch {
      setCheckoutLoading(false);
    }
  };

  if (isLoading) return <div className="container-main py-16 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-ink-subtle" /></div>;

  if (!items.length) {
    return (
      <div className="container-main py-16 text-center">
        <ShoppingBag className="w-16 h-16 text-ink-subtle mx-auto mb-4" />
        <h1 className="text-xl font-bold text-ink mb-2">Seu carrinho está vazio</h1>
        <p className="text-ink-muted mb-6">Adicione produtos para continuar</p>
        <Link href="/products" className="btn-secondary">Ver produtos</Link>
      </div>
    );
  }

  return (
    <div className="container-main py-8">
      <h1 className="text-2xl font-bold text-ink mb-8">Carrinho de compras</h1>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div key={item.id} className="card p-4 flex gap-4">
              <div className="w-24 h-24 relative rounded-lg overflow-hidden bg-surface-muted flex-shrink-0">
                <Image src={item.product.images[0] || "/images/placeholder.png"} alt={item.product.title} fill className="object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-ink text-sm line-clamp-2">{item.product.title}</h3>
                <p className="text-xs text-ink-subtle mt-1">Vendido por {item.product.seller.name}</p>
                <p className="text-lg font-bold text-ink mt-2">{formatPrice(item.product.price)}</p>
              </div>
              <div className="flex flex-col items-end justify-between">
                <button onClick={() => removeItem(item.productId)} className="text-ink-subtle hover:text-danger transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="w-8 h-8 rounded-lg bg-surface-muted flex items-center justify-center hover:bg-surface-subtle transition-colors">
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-sm font-medium w-8 text-center">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="w-8 h-8 rounded-lg bg-surface-muted flex items-center justify-center hover:bg-surface-subtle transition-colors">
                    <Plus className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="card p-6 h-fit sticky top-24">
          <h2 className="font-bold text-ink mb-4">Resumo da compra</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-ink-muted">
              <span>Produtos ({items.length})</span>
              <span>{formatPrice(total)}</span>
            </div>
            <div className="flex justify-between text-ink-muted">
              <span>Frete</span>
              <span className="text-success">Grátis</span>
            </div>
          </div>
          <div className="border-t mt-4 pt-4 flex justify-between font-bold text-ink">
            <span>Total</span>
            <span>{formatPrice(total)}</span>
          </div>
          <button onClick={handleCheckout} disabled={checkoutLoading} className="btn-secondary w-full mt-4 flex items-center justify-center gap-2">
            {checkoutLoading && <Loader2 className="w-4 h-4 animate-spin" />}
            Finalizar compra
          </button>
        </div>
      </div>
    </div>
  );
}

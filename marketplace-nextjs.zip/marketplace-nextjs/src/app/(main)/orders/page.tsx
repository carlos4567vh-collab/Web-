"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { formatPrice, formatDate } from "@/lib/utils";
import { Package, Loader2 } from "lucide-react";

const STATUS_MAP: Record<string, { label: string; class: string }> = {
  PENDING: { label: "Pendente", class: "badge-warning" },
  PAID: { label: "Pago", class: "badge-info" },
  SHIPPED: { label: "Enviado", class: "badge-info" },
  DELIVERED: { label: "Entregue", class: "badge-success" },
  CANCELLED: { label: "Cancelado", class: "badge-danger" },
};

export default function OrdersPage() {
  const { data: session } = useSession();
  const router = useRouter();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session) { router.push("/login"); return; }
    fetch("/api/orders").then((r) => r.json()).then(setOrders).finally(() => setLoading(false));
  }, [session, router]);

  if (loading) return <div className="container-main py-16 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-ink-subtle" /></div>;

  if (!orders.length) {
    return (
      <div className="container-main py-16 text-center">
        <Package className="w-16 h-16 text-ink-subtle mx-auto mb-4" />
        <h1 className="text-xl font-bold text-ink mb-2">Nenhum pedido ainda</h1>
        <Link href="/products" className="btn-secondary mt-4 inline-block">Explorar produtos</Link>
      </div>
    );
  }

  return (
    <div className="container-main py-8">
      <h1 className="text-2xl font-bold text-ink mb-8">Meus pedidos</h1>
      <div className="space-y-4">
        {orders.map((order: any) => {
          const status = STATUS_MAP[order.status] || STATUS_MAP.PENDING;
          return (
            <Link key={order.id} href={`/orders/${order.id}`} className="card p-5 block hover:shadow-elevated transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <span className="text-xs text-ink-subtle">Pedido #{order.id.slice(0, 8)}</span>
                  <span className="text-xs text-ink-subtle ml-3">{formatDate(order.createdAt)}</span>
                </div>
                <span className={status.class}>{status.label}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-ink-muted">{order.items.length} {order.items.length === 1 ? "item" : "itens"}</span>
                <span className="font-bold text-ink">{formatPrice(order.total)}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

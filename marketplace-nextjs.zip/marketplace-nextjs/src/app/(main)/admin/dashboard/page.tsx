"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Users, Package, Tags, BarChart3, Loader2 } from "lucide-react";

export default function AdminDashboard() {
  const { data: session } = useSession();
  const router = useRouter();
  const user = session?.user as any;
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session || user?.role !== "ADMIN") { router.push("/"); return; }
    fetch("/api/admin/stats").then((r) => r.json()).then(setStats).finally(() => setLoading(false));
  }, [session, router, user]);

  if (loading) return <div className="container-main py-16 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>;

  const cards = [
    { icon: Users, label: "Usuários", value: stats?.users || 0, href: "/admin/users", color: "text-info" },
    { icon: Package, label: "Produtos", value: stats?.products || 0, href: "/admin/products", color: "text-success" },
    { icon: Tags, label: "Categorias", value: stats?.categories || 0, href: "/admin/categories", color: "text-brand-700" },
    { icon: BarChart3, label: "Pedidos", value: stats?.orders || 0, href: "#", color: "text-danger" },
  ];

  return (
    <div className="container-main py-8">
      <h1 className="text-2xl font-bold text-ink mb-8">Painel Administrativo</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(({ icon: Icon, label, value, href, color }) => (
          <Link key={label} href={href} className="card p-6 hover:shadow-elevated transition-shadow">
            <Icon className={`w-8 h-8 ${color} mb-3`} />
            <p className="text-2xl font-bold text-ink">{value}</p>
            <p className="text-sm text-ink-muted">{label}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

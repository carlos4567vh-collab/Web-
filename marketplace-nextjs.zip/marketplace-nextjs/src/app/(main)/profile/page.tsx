"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { User, MapPin, Heart, Package, Store, Settings } from "lucide-react";

export default function ProfilePage() {
  const { data: session } = useSession();
  const router = useRouter();
  const user = session?.user as any;

  if (!session) { router.push("/login"); return null; }

  const links = [
    { href: "/orders", icon: Package, label: "Meus pedidos", desc: "Acompanhe suas compras" },
    { href: "/profile/wishlist", icon: Heart, label: "Favoritos", desc: "Produtos que você curtiu" },
    { href: "/profile/addresses", icon: MapPin, label: "Endereços", desc: "Gerencie seus endereços" },
  ];

  if (user?.role === "SELLER") links.push({ href: "/seller/dashboard", icon: Store, label: "Painel do vendedor", desc: "Gerencie suas vendas" });

  return (
    <div className="container-main py-8">
      <div className="card p-6 mb-8 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-brand-100 flex items-center justify-center text-2xl font-bold text-brand-700">
          {user?.name?.[0] || "U"}
        </div>
        <div>
          <h1 className="text-xl font-bold text-ink">{user?.name}</h1>
          <p className="text-sm text-ink-muted">{user?.email}</p>
          <span className="badge-info mt-1">{user?.role}</span>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {links.map(({ href, icon: Icon, label, desc }) => (
          <Link key={href} href={href} className="card p-5 flex items-center gap-4 hover:shadow-elevated transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center">
              <Icon className="w-6 h-6 text-brand-700" />
            </div>
            <div>
              <h3 className="font-semibold text-ink text-sm">{label}</h3>
              <p className="text-xs text-ink-muted">{desc}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

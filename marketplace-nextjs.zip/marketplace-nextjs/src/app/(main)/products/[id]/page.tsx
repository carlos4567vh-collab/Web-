import { notFound } from "next/navigation";
import Image from "next/image";
import { ProductService } from "@/services/product.service";
import { formatPrice, formatDate } from "@/lib/utils";
import { AddToCartButton } from "@/components/cart/AddToCartButton";
import { ReviewList } from "@/components/reviews/ReviewList";
import { Star, Truck, Shield, ArrowLeft } from "lucide-react";
import Link from "next/link";
import type { Metadata } from "next";

interface Props { params: { id: string } }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await ProductService.getBySlug(params.id);
  if (!product) return { title: "Produto não encontrado" };
  return {
    title: `${product.title} - Marketplace`,
    description: product.description.slice(0, 160),
  };
}

export default async function ProductPage({ params }: Props) {
  const product = await ProductService.getBySlug(params.id);
  if (!product) notFound();

  const avgRating = product.reviews.length
    ? (product.reviews.reduce((s: number, r: any) => s + r.rating, 0) / product.reviews.length).toFixed(1)
    : null;

  return (
    <div className="container-main py-8">
      <Link href="/products" className="inline-flex items-center gap-1 text-sm text-ink-muted hover:text-info mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Voltar
      </Link>

      <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Images */}
        <div className="space-y-3">
          <div className="aspect-square relative rounded-xl overflow-hidden bg-surface-muted">
            <Image src={product.images[0] || "/images/placeholder.png"} alt={product.title} fill className="object-cover" priority />
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto">
              {product.images.map((img: string, i: number) => (
                <div key={i} className="w-20 h-20 relative rounded-lg overflow-hidden bg-surface-muted flex-shrink-0 border-2 border-transparent hover:border-info transition-colors">
                  <Image src={img} alt="" fill className="object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <p className="text-sm text-ink-subtle mb-1">{(product as any).category?.name}</p>
          <h1 className="text-2xl font-bold text-ink mb-3" style={{ lineHeight: "1.2" }}>{product.title}</h1>

          {avgRating && (
            <div className="flex items-center gap-2 mb-4">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className={`w-4 h-4 ${s <= Math.round(Number(avgRating)) ? "fill-brand-500 text-brand-500" : "text-surface-subtle"}`} />
                ))}
              </div>
              <span className="text-sm text-ink-muted">{avgRating} ({product.reviews.length} avaliações)</span>
            </div>
          )}

          <p className="text-3xl font-bold text-ink mb-1">{formatPrice(product.price)}</p>
          <p className="text-sm text-success font-medium mb-6">em até 12x de {formatPrice(product.price / 12)} sem juros</p>

          <div className="space-y-3 mb-6">
            <div className="flex items-center gap-2 text-sm text-ink-muted">
              <Truck className="w-4 h-4 text-success" />
              <span>Frete grátis para todo o Brasil</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-ink-muted">
              <Shield className="w-4 h-4 text-info" />
              <span>Compra garantida</span>
            </div>
          </div>

          <p className="text-sm text-ink-muted mb-2">
            Estoque: <span className={product.stock > 0 ? "text-success" : "text-danger"}>{product.stock > 0 ? `${product.stock} disponíveis` : "Esgotado"}</span>
          </p>

          <AddToCartButton productId={product.id} disabled={product.stock <= 0} />

          <div className="mt-8 pt-6 border-t">
            <h2 className="font-semibold text-ink mb-3">Descrição</h2>
            <p className="text-sm text-ink-muted leading-relaxed whitespace-pre-line">{product.description}</p>
          </div>

          <div className="mt-4 text-xs text-ink-subtle">
            Vendido por <span className="font-medium text-ink-muted">{(product as any).seller?.name}</span>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <div className="mt-12 pt-8 border-t">
        <h2 className="text-xl font-bold text-ink mb-6">Avaliações</h2>
        <ReviewList reviews={product.reviews} productId={product.id} />
      </div>
    </div>
  );
}

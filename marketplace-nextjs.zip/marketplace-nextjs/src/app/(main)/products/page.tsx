import { Suspense } from "react";
import { prisma } from "@/lib/prisma";
import { ProductService } from "@/services/product.service";
import { ProductGrid } from "@/components/products/ProductGrid";
import { SearchFilters } from "@/components/products/SearchFilters";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Produtos - Marketplace",
  description: "Explore nossa seleção de produtos com os melhores preços",
};

interface Props {
  searchParams: { [key: string]: string | undefined };
}

export default async function ProductsPage({ searchParams }: Props) {
  const [result, categories] = await Promise.all([
    ProductService.list({
      search: searchParams.search,
      categoryId: searchParams.categoryId,
      minPrice: searchParams.minPrice ? Number(searchParams.minPrice) : undefined,
      maxPrice: searchParams.maxPrice ? Number(searchParams.maxPrice) : undefined,
      sortBy: searchParams.sortBy as any,
      page: Number(searchParams.page) || 1,
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="container-main py-8">
      {searchParams.search && (
        <h1 className="text-lg text-ink-muted mb-6">
          Resultados para <span className="font-semibold text-ink">"{searchParams.search}"</span>
          <span className="text-sm ml-2">({(result as any).total} encontrados)</span>
        </h1>
      )}

      <div className="flex gap-8">
        <div className="hidden lg:block w-56 flex-shrink-0">
          <Suspense>
            <SearchFilters categories={categories} />
          </Suspense>
        </div>
        <div className="flex-1">
          <ProductGrid products={(result as any).data || []} />

          {/* Pagination */}
          {(result as any).totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-8">
              {Array.from({ length: (result as any).totalPages }, (_, i) => i + 1).map((page) => (
                <a
                  key={page}
                  href={`/products?${new URLSearchParams({ ...searchParams, page: String(page) } as any).toString()}`}
                  className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm transition-colors ${
                    page === ((result as any).page || 1) ? "bg-info text-white" : "bg-surface-muted text-ink-muted hover:bg-surface-subtle"
                  }`}
                >
                  {page}
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

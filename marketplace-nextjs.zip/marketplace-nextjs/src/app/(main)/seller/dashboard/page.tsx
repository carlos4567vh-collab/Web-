"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { formatPrice } from "@/lib/utils";
import { Package, Plus, DollarSign, ShoppingBag, Loader2 } from "lucide-react";

export default function SellerDashboard() {
  const { data: session } = useSession();
  const router = useRouter();
  const user = session?.user as any;
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session || (user?.role !== "SELLER" && user?.role !== "ADMIN")) {
      router.push("/"); return;
    }
    fetch(`/api/products?sellerId=${user.id}`).then((r) => r.json()).then((d) => setProducts(d.data || [])).finally(() => setLoading(false));
  }, [session, router, user]);

  if (loading) return <div className="container-main py-16 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>;

  const totalRevenue = products.reduce((s: number, p: any) => s + (p._count?.orderItems || 0) * p.price, 0);
  const totalSold = products.reduce((s: number, p: any) => s + (p._count?.orderItems || 0), 0);

  return (
    <div className="container-main py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-ink">Painel do Vendedor</h1>
        <Link href="/seller/products/new" className="btn-secondary flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" /> Novo produto
        </Link>
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        {[
          { icon: Package, label: "Produtos", value: products.length, color: "text-info" },
          { icon: ShoppingBag, label: "Vendas", value: totalSold, color: "text-success" },
          { icon: DollarSign, label: "Receita", value: formatPrice(totalRevenue), color: "text-brand-700" },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="card p-5">
            <div className="flex items-center gap-3">
              <Icon className={`w-8 h-8 ${color}`} />
              <div>
                <p className="text-sm text-ink-muted">{label}</p>
                <p className="text-xl font-bold text-ink">{value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <h2 className="font-bold text-ink mb-4">Meus Produtos</h2>
      <div className="space-y-3">
        {products.map((p: any) => (
          <Link key={p.id} href={`/seller/products/${p.id}`} className="card p-4 flex items-center gap-4 hover:shadow-elevated transition-shadow">
            <div className="w-16 h-16 rounded-lg bg-surface-muted flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-ink text-sm truncate">{p.title}</h3>
              <p className="text-xs text-ink-subtle">{p.category?.name} · Estoque: {p.stock}</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-ink">{formatPrice(p.price)}</p>
              <p className="text-xs text-ink-subtle">{p._count?.orderItems || 0} vendas</p>
            </div>
          </Link>
        ))}
        {!products.length && <p className="text-ink-muted text-sm">Nenhum produto cadastrado. Crie seu primeiro!</p>}
      </div>
    </div>
  );
}

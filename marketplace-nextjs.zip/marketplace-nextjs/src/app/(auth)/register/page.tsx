import { RegisterForm } from "@/components/auth/RegisterForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Criar conta - Marketplace",
  description: "Crie sua conta no Marketplace e comece a comprar",
};

export default function RegisterPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <h1 className="text-2xl font-bold text-ink text-center mb-8">Criar sua conta</h1>
        <div className="card p-6 sm:p-8">
          <RegisterForm />
        </div>
      </div>
    </div>
  );
}

import { LoginForm } from "@/components/auth/LoginForm";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Entrar - Marketplace",
  description: "Faça login na sua conta Marketplace",
};

export default function LoginPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <h1 className="text-2xl font-bold text-ink text-center mb-8">Entrar na sua conta</h1>
        <div className="card p-6 sm:p-8">
          <LoginForm />
        </div>
      </div>
    </div>
  );
}

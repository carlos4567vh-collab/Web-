import { CartRepository } from "@/repositories/cart.repository";

export class CartService {
  static async getCart(userId: string) {
    return CartRepository.findOrCreate(userId);
  }

  static async addItem(userId: string, productId: string, quantity = 1) {
    return CartRepository.addItem(userId, productId, quantity);
  }

  static async updateQuantity(userId: string, productId: string, quantity: number) {
    return CartRepository.updateItem(userId, productId, quantity);
  }

  static async removeItem(userId: string, productId: string) {
    return CartRepository.removeItem(userId, productId);
  }

  static async clearCart(userId: string) {
    return CartRepository.clear(userId);
  }
}

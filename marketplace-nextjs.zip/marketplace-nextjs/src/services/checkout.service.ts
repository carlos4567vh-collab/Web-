import { stripe } from "@/lib/stripe";
import { CartRepository } from "@/repositories/cart.repository";
import { OrderRepository } from "@/repositories/order.repository";
import { prisma } from "@/lib/prisma";

export class CheckoutService {
  static async createSession(userId: string) {
    const cart = await CartRepository.findOrCreate(userId);
    if (!cart.items.length) throw new Error("Carrinho vazio");

    // Validate stock
    for (const item of cart.items) {
      if (item.product.stock < item.quantity) {
        throw new Error(`Estoque insuficiente para ${item.product.title}`);
      }
    }

    const total = cart.items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

    const lineItems = cart.items.map((item) => ({
      price_data: {
        currency: "brl",
        product_data: {
          name: item.product.title,
          images: item.product.images.slice(0, 1),
        },
        unit_amount: Math.round(item.product.price * 100),
      },
      quantity: item.quantity,
    }));

    // Create order first
    const order = await OrderRepository.create(
      userId,
      cart.items.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
        price: item.product.price,
      })),
      total
    );

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/orders/${order.id}?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/cart?cancelled=true`,
      metadata: { orderId: order.id, userId },
    });

    await OrderRepository.updateStatus(order.id, "PENDING");
    await prisma.order.update({ where: { id: order.id }, data: { stripeId: session.id } });

    return { sessionId: session.id, url: session.url };
  }

  static async handleWebhook(event: any) {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object;
        const orderId = session.metadata.orderId;

        await OrderRepository.updateStatus(orderId, "PAID");
        await OrderRepository.updatePaymentStatus(orderId, "COMPLETED");

        // Reduce stock
        const order = await OrderRepository.findById(orderId);
        if (order) {
          for (const item of order.items) {
            await prisma.product.update({
              where: { id: item.productId },
              data: { stock: { decrement: item.quantity } },
            });
          }
          // Clear cart
          await CartRepository.clear(order.userId);
        }
        break;
      }
      case "checkout.session.expired": {
        const session = event.data.object;
        const orderId = session.metadata?.orderId;
        if (orderId) {
          await OrderRepository.updateStatus(orderId, "CANCELLED");
          await OrderRepository.updatePaymentStatus(orderId, "FAILED");
        }
        break;
      }
    }
  }
}

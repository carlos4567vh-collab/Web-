import { ProductRepository } from "@/repositories/product.repository";
import { ProductFilters } from "@/types";
import { ProductInput } from "@/lib/validations";
import { slugify } from "@/lib/utils";
import { uploadImage } from "@/lib/cloudinary";
import { cacheDel, cacheGet, cacheSet } from "@/lib/redis";

export class ProductService {
  static async list(filters: ProductFilters) {
    const cacheKey = `products:${JSON.stringify(filters)}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return cached;

    const result = await ProductRepository.findMany(filters);
    await cacheSet(cacheKey, result, 120);
    return result;
  }

  static async getBySlug(slug: string) {
    const cacheKey = `product:${slug}`;
    const cached = await cacheGet(cacheKey);
    if (cached) return cached;

    const product = await ProductRepository.findBySlug(slug);
    if (product) await cacheSet(cacheKey, product, 300);
    return product;
  }

  static async getById(id: string) {
    return ProductRepository.findById(id);
  }

  static async create(sellerId: string, data: ProductInput, imageFiles: string[]) {
    const images = await Promise.all(imageFiles.map(uploadImage));
    const slug = slugify(data.title) + "-" + Date.now().toString(36);

    const product = await ProductRepository.create({
      ...data,
      slug,
      images,
      seller: { connect: { id: sellerId } },
      category: { connect: { id: data.categoryId } },
    });

    await cacheDel("products:*");
    return product;
  }

  static async update(id: string, sellerId: string, data: Partial<ProductInput>, newImages?: string[]) {
    const existing = await ProductRepository.findById(id);
    if (!existing || existing.sellerId !== sellerId) throw new Error("Produto não encontrado");

    let images = existing.images;
    if (newImages?.length) {
      const uploaded = await Promise.all(newImages.map(uploadImage));
      images = [...images, ...uploaded];
    }

    const product = await ProductRepository.update(id, { ...data, images });
    await cacheDel("products:*");
    await cacheDel(`product:${existing.slug}`);
    return product;
  }

  static async delete(id: string, sellerId: string) {
    const existing = await ProductRepository.findById(id);
    if (!existing || existing.sellerId !== sellerId) throw new Error("Produto não encontrado");

    await ProductRepository.delete(id);
    await cacheDel("products:*");
    await cacheDel(`product:${existing.slug}`);
  }

  static async getBySeller(sellerId: string) {
    return ProductRepository.findBySeller(sellerId);
  }
}

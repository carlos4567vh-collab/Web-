import { create } from "zustand";

interface CartItem {
  id: string;
  productId: string;
  quantity: number;
  product: {
    id: string;
    title: string;
    price: number;
    images: string[];
    stock: number;
    seller: { id: string; name: string };
  };
}

interface CartStore {
  items: CartItem[];
  isLoading: boolean;
  setItems: (items: CartItem[]) => void;
  setLoading: (loading: boolean) => void;
  itemCount: () => number;
  total: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  isLoading: false,
  setItems: (items) => set({ items }),
  setLoading: (isLoading) => set({ isLoading }),
  itemCount: () => get().items.reduce((sum, item) => sum + item.quantity, 0),
  total: () => get().items.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
}));

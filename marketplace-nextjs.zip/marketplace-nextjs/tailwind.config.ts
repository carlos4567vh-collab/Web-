import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#FFF8E1",
          100: "#FFECB3",
          200: "#FFE082",
          300: "#FFD54F",
          400: "#FFCA28",
          500: "#FFC107",
          600: "#FFB300",
          700: "#FFA000",
          800: "#FF8F00",
          900: "#FF6F00",
        },
        surface: {
          DEFAULT: "#FFFFFF",
          muted: "#F5F5F5",
          subtle: "#EEEEEE",
        },
        ink: {
          DEFAULT: "#212121",
          muted: "#757575",
          subtle: "#9E9E9E",
        },
        success: "#4CAF50",
        danger: "#F44336",
        info: "#2196F3",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 3px 0 rgb(0 0 0 / 0.06), 0 1px 2px -1px rgb(0 0 0 / 0.06)",
        elevated: "0 4px 12px 0 rgb(0 0 0 / 0.08)",
        float: "0 8px 24px 0 rgb(0 0 0 / 0.12)",
      },
    },
  },
  plugins: [],
};

export default config;

# 🛒 Marketplace - Next.js 14

Marketplace completo estilo Mercado Livre, construído com Next.js 14 (App Router).

## Stack

- **Framework:** Next.js 14 (App Router)
- **Linguagem:** TypeScript
- **Estilização:** TailwindCSS
- **ORM:** Prisma + PostgreSQL
- **Autenticação:** NextAuth (JWT)
- **Pagamento:** Stripe
- **Upload:** Cloudinary
- **Estado:** Zustand
- **Validação:** React Hook Form + Zod
- **Cache:** Redis (opcional)

## Instalação

```bash
# 1. Instale as dependências
npm install

# 2. Configure o .env
cp .env.example .env
# Edite o .env com suas credenciais

# 3. Gere o Prisma Client
npx prisma generate

# 4. Execute as migrations
npx prisma migrate dev

# 5. Popule o banco (opcional)
npx prisma db seed

# 6. Inicie o servidor
npm run dev
```

## Credenciais de Teste (após seed)

| Role   | Email                     | Senha     |
|--------|---------------------------|-----------|
| Admin  | admin@marketplace.com     | admin123  |
| Seller | vendedor@marketplace.com  | seller123 |

## Estrutura do Projeto

```
src/
├── app/                  # Rotas (App Router)
│   ├── api/              # API Routes
│   ├── (auth)/           # Páginas de autenticação
│   └── (main)/           # Páginas principais
├── components/           # Componentes React
│   ├── ui/               # Componentes base
│   ├── layout/           # Header, Footer, Providers
│   ├── products/         # Card, Grid, Filters
│   ├── cart/              # Botão Add, Cart page
│   ├── auth/             # Login, Register forms
│   ├── reviews/          # Lista e form de reviews
│   ├── seller/           # Dashboard do vendedor
│   └── admin/            # Dashboard admin
├── hooks/                # Custom hooks
├── lib/                  # Utilitários (prisma, auth, stripe, etc.)
├── repositories/         # Camada de dados
├── services/             # Lógica de negócio
├── store/                # Zustand stores
└── types/                # TypeScript types
```

## Funcionalidades

- ✅ Autenticação (registro/login com JWT)
- ✅ CRUD de produtos com busca avançada
- ✅ Carrinho persistente no banco
- ✅ Checkout com Stripe
- ✅ Webhook de pagamento
- ✅ Pedidos com status
- ✅ Reviews e avaliações
- ✅ Wishlist
- ✅ Perfil e endereços
- ✅ Painel do vendedor
- ✅ Painel administrativo
- ✅ Middleware de proteção de rotas
- ✅ Validação com Zod
- ✅ Cache com Redis (opcional)
- ✅ SEO com meta tags
- ✅ Responsivo (mobile-first)
- ✅ Seed de dados

## Deploy

### Vercel
1. Conecte o repositório na Vercel
2. Configure as variáveis de ambiente
3. Deploy automático

### Docker
```bash
docker build -t marketplace .
docker run -p 3000:3000 --env-file .env marketplace
```

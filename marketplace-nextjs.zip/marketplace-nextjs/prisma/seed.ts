import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // Categories
  const categories = await Promise.all(
    ["Eletrônicos", "Moda", "Casa e Decoração", "Esportes", "Livros", "Beleza", "Brinquedos", "Automotivo"].map((name) =>
      prisma.category.upsert({
        where: { slug: name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-") },
        update: {},
        create: { name, slug: name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-") },
      })
    )
  );

  // Admin user
  const adminPassword = await bcrypt.hash("admin123", 12);
  await prisma.user.upsert({
    where: { email: "admin@marketplace.com" },
    update: {},
    create: { name: "Administrador", email: "admin@marketplace.com", password: adminPassword, role: "ADMIN", emailVerified: new Date() },
  });

  // Seller user
  const sellerPassword = await bcrypt.hash("seller123", 12);
  const seller = await prisma.user.upsert({
    where: { email: "vendedor@marketplace.com" },
    update: {},
    create: { name: "Maria Santos", email: "vendedor@marketplace.com", password: sellerPassword, role: "SELLER", emailVerified: new Date() },
  });

  // Sample products
  const sampleProducts = [
    { title: "Fone Bluetooth Premium", description: "Fone de ouvido sem fio com cancelamento de ruído ativo, bateria de 30h e som Hi-Fi.", price: 299.9, stock: 50, categorySlug: "eletronicos" },
    { title: "Camiseta Algodão Orgânico", description: "Camiseta premium 100% algodão orgânico. Confortável e sustentável.", price: 89.9, stock: 100, categorySlug: "moda" },
    { title: "Luminária LED Moderna", description: "Luminária de mesa com 3 temperaturas de cor e dimmer touch.", price: 159.9, stock: 30, categorySlug: "casa-e-decoracao" },
    { title: "Tênis Running Pro", description: "Tênis para corrida com amortecimento em gel e solado antiderrapante.", price: 449.9, stock: 25, categorySlug: "esportes" },
    { title: "Smartwatch Fitness", description: "Relógio inteligente com monitor cardíaco, GPS e resistência à água.", price: 599.9, stock: 40, categorySlug: "eletronicos" },
  ];

  for (const p of sampleProducts) {
    const cat = categories.find((c) => c.slug === p.categorySlug);
    if (!cat) continue;
    await prisma.product.upsert({
      where: { slug: p.title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-") },
      update: {},
      create: {
        title: p.title,
        slug: p.title.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-"),
        description: p.description,
        price: p.price,
        stock: p.stock,
        images: [],
        sellerId: seller.id,
        categoryId: cat.id,
      },
    });
  }

  console.log("Seed completed!");
}

main().catch(console.error).finally(() => prisma.$disconnect());
